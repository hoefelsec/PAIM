/* @ds-bundle: {"format":4,"namespace":"ForgeDesignSystem_8868ce","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"ICON_NAMES","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Kbd","sourcePath":"components/core/Kbd.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"EmptyState","sourcePath":"components/feedback/EmptyState.jsx"},{"name":"ProgressBar","sourcePath":"components/feedback/ProgressBar.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"Breadcrumbs","sourcePath":"components/navigation/Breadcrumbs.jsx"},{"name":"SidebarItem","sourcePath":"components/navigation/SidebarItem.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"AgentRunIndicator","sourcePath":"components/product/AgentRunIndicator.jsx"},{"name":"ApprovalBanner","sourcePath":"components/product/ApprovalBanner.jsx"},{"name":"ExecutionLog","sourcePath":"components/product/ExecutionLog.jsx"},{"name":"STATUSES","sourcePath":"components/product/StatusPill.jsx"},{"name":"StatusPill","sourcePath":"components/product/StatusPill.jsx"},{"name":"TaskCard","sourcePath":"components/product/TaskCard.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"5f567cc56d6d","components/core/Badge.jsx":"553b3f7cc588","components/core/Button.jsx":"ad48f5f49402","components/core/Card.jsx":"c50991d57ce2","components/core/Icon.jsx":"e10c149f9d02","components/core/IconButton.jsx":"45277f832c2f","components/core/Kbd.jsx":"e66857612da3","components/core/Tag.jsx":"1ffbabe5e33e","components/feedback/Dialog.jsx":"78f92bbb4ad0","components/feedback/EmptyState.jsx":"e3530ff1d5d0","components/feedback/ProgressBar.jsx":"bf172f875cd3","components/feedback/Toast.jsx":"59ad6dd002af","components/feedback/Tooltip.jsx":"bc3ca328f733","components/forms/Checkbox.jsx":"68627f319b3e","components/forms/Input.jsx":"984a21cafb51","components/forms/Radio.jsx":"dd56138862c7","components/forms/Select.jsx":"71eef90e53ad","components/forms/Switch.jsx":"3edf720ca244","components/forms/Textarea.jsx":"97bf9adb1159","components/navigation/Breadcrumbs.jsx":"3994516e2fab","components/navigation/SidebarItem.jsx":"62d59b373269","components/navigation/Tabs.jsx":"9ed29360c6a5","components/product/AgentRunIndicator.jsx":"53810e13fcb4","components/product/ApprovalBanner.jsx":"694268f1ddc5","components/product/ExecutionLog.jsx":"2002ad5eab2d","components/product/StatusPill.jsx":"d4e2ef02964a","components/product/TaskCard.jsx":"0b692c1e9685","ui_kits/forge-app/AppShell.jsx":"4170e8905d5a","ui_kits/forge-app/BoardScreen.jsx":"df748869e820","ui_kits/forge-app/TaskView.jsx":"701f1a7eb59b","ui_kits/forge-app/data.js":"b6dbaed81c3d","ui_kits/forge-web/ChangelogPage.jsx":"6247fff96dea","ui_kits/forge-web/HomePage.jsx":"235166ce7043","ui_kits/forge-web/PricingPage.jsx":"a02d32ccd63f","ui_kits/forge-web/SiteChrome.jsx":"78cd19805256"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ForgeDesignSystem_8868ce = window.ForgeDesignSystem_8868ce || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const PAD = {
  none: 0,
  sm: 'var(--space-5)',
  md: 'var(--space-6)',
  lg: 'var(--space-8)'
};
function Card({
  children,
  padding = 'md',
  elevation = 'sm',
  interactive = false,
  selected = false,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const shadow = {
    none: 'none',
    sm: 'var(--shadow-sm)',
    md: 'var(--shadow-md)',
    lg: 'var(--shadow-lg)'
  }[elevation];
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-lg)',
      border: '1px solid ' + (selected ? 'var(--border-accent)' : 'var(--border-default)'),
      boxShadow: selected ? 'var(--shadow-md)' : shadow,
      padding: PAD[padding],
      transition: 'box-shadow var(--duration-normal) var(--ease-standard), border-color var(--duration-fast) var(--ease-standard), transform var(--duration-normal) var(--ease-standard)',
      cursor: interactive ? 'pointer' : undefined,
      ...(interactive && hover ? {
        boxShadow: 'var(--shadow-md)',
        transform: 'translateY(-1px)'
      } : null),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Lucide 0.544.0 (ISC) — the same SVG files that live in assets/icons/, inlined as data URIs
   so glyphs resolve with no network and survive static capture/export. */
const GLYPHS = {
  "arrow-left": "%3Csvg%20class%3D%22lucide%20lucide-arrow-left%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22m12%2019-7-7%207-7%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M19%2012H5%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "arrow-right": "%3Csvg%20class%3D%22lucide%20lucide-arrow-right%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M5%2012h14%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22m12%205%207%207-7%207%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "bell": "%3Csvg%20class%3D%22lucide%20lucide-bell%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M10.268%2021a2%202%200%200%200%203.464%200%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M3.262%2015.326A1%201%200%200%200%204%2017h16a1%201%200%200%200%20.74-1.673C19.41%2013.956%2018%2012.499%2018%208A6%206%200%200%200%206%208c0%204.499-1.411%205.956-2.738%207.326%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "building-2": "%3Csvg%20class%3D%22lucide%20lucide-building-2%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M6%2022V4a2%202%200%200%201%202-2h8a2%202%200%200%201%202%202v18Z%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M6%2012H4a2%202%200%200%200-2%202v6a2%202%200%200%200%202%202h2%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M18%209h2a2%202%200%200%201%202%202v9a2%202%200%200%201-2%202h-2%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M10%206h4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M10%2010h4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M10%2014h4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M10%2018h4%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "calendar": "%3Csvg%20class%3D%22lucide%20lucide-calendar%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M8%202v4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M16%202v4%22%3E%3C%2Fpath%3E%20%3Crect%20width%3D%2218%22%20height%3D%2218%22%20x%3D%223%22%20y%3D%224%22%20rx%3D%222%22%3E%3C%2Frect%3E%20%3Cpath%20d%3D%22M3%2010h18%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "check-check": "%3Csvg%20class%3D%22lucide%20lucide-check-check%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M18%206%207%2017l-5-5%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22m22%2010-7.5%207.5L13%2016%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "check": "%3Csvg%20class%3D%22lucide%20lucide-check%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M20%206%209%2017l-5-5%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "chevron-down": "%3Csvg%20class%3D%22lucide%20lucide-chevron-down%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22m6%209%206%206%206-6%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "chevron-right": "%3Csvg%20class%3D%22lucide%20lucide-chevron-right%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22m9%2018%206-6-6-6%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "circle-alert": "%3Csvg%20class%3D%22lucide%20lucide-circle-alert%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%2210%22%3E%3C%2Fcircle%3E%20%3Cline%20x1%3D%2212%22%20x2%3D%2212%22%20y1%3D%228%22%20y2%3D%2212%22%3E%3C%2Fline%3E%20%3Cline%20x1%3D%2212%22%20x2%3D%2212.01%22%20y1%3D%2216%22%20y2%3D%2216%22%3E%3C%2Fline%3E%20%3C%2Fsvg%3E",
  "circle-check": "%3Csvg%20class%3D%22lucide%20lucide-circle-check%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%2210%22%3E%3C%2Fcircle%3E%20%3Cpath%20d%3D%22m9%2012%202%202%204-4%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "circle-dashed": "%3Csvg%20class%3D%22lucide%20lucide-circle-dashed%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M10.1%202.182a10%2010%200%200%201%203.8%200%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M13.9%2021.818a10%2010%200%200%201-3.8%200%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M17.609%203.721a10%2010%200%200%201%202.69%202.7%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M2.182%2013.9a10%2010%200%200%201%200-3.8%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M20.279%2017.609a10%2010%200%200%201-2.7%202.69%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M21.818%2010.1a10%2010%200%200%201%200%203.8%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M3.721%206.391a10%2010%200%200%201%202.7-2.69%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M6.391%2020.279a10%2010%200%200%201-2.69-2.7%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "circle-dot": "%3Csvg%20class%3D%22lucide%20lucide-circle-dot%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%2210%22%3E%3C%2Fcircle%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%221%22%3E%3C%2Fcircle%3E%20%3C%2Fsvg%3E",
  "circle-help": "%3Csvg%20class%3D%22lucide%20lucide-circle-help%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%2210%22%3E%3C%2Fcircle%3E%20%3Cpath%20d%3D%22M9.09%209a3%203%200%200%201%205.83%201c0%202-3%203-3%203%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M12%2017h.01%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "circle-pause": "%3Csvg%20class%3D%22lucide%20lucide-circle-pause%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%2210%22%3E%3C%2Fcircle%3E%20%3Cline%20x1%3D%2210%22%20x2%3D%2210%22%20y1%3D%2215%22%20y2%3D%229%22%3E%3C%2Fline%3E%20%3Cline%20x1%3D%2214%22%20x2%3D%2214%22%20y1%3D%2215%22%20y2%3D%229%22%3E%3C%2Fline%3E%20%3C%2Fsvg%3E",
  "circle-slash": "%3Csvg%20class%3D%22lucide%20lucide-circle-slash%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%2210%22%3E%3C%2Fcircle%3E%20%3Cline%20x1%3D%229%22%20x2%3D%2215%22%20y1%3D%2215%22%20y2%3D%229%22%3E%3C%2Fline%3E%20%3C%2Fsvg%3E",
  "circle-user-round": "%3Csvg%20class%3D%22lucide%20lucide-circle-user-round%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M18%2020a6%206%200%200%200-12%200%22%3E%3C%2Fpath%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2210%22%20r%3D%224%22%3E%3C%2Fcircle%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%2210%22%3E%3C%2Fcircle%3E%20%3C%2Fsvg%3E",
  "circle-x": "%3Csvg%20class%3D%22lucide%20lucide-circle-x%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%2210%22%3E%3C%2Fcircle%3E%20%3Cpath%20d%3D%22m15%209-6%206%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22m9%209%206%206%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "circle": "%3Csvg%20class%3D%22lucide%20lucide-circle%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%2210%22%3E%3C%2Fcircle%3E%20%3C%2Fsvg%3E",
  "clock": "%3Csvg%20class%3D%22lucide%20lucide-clock%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M12%206v6l4%202%22%3E%3C%2Fpath%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%2210%22%3E%3C%2Fcircle%3E%20%3C%2Fsvg%3E",
  "columns-3": "%3Csvg%20class%3D%22lucide%20lucide-columns-3%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Crect%20width%3D%2218%22%20height%3D%2218%22%20x%3D%223%22%20y%3D%223%22%20rx%3D%222%22%3E%3C%2Frect%3E%20%3Cpath%20d%3D%22M9%203v18%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M15%203v18%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "command": "%3Csvg%20class%3D%22lucide%20lucide-command%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M15%206v12a3%203%200%201%200%203-3H6a3%203%200%201%200%203%203V6a3%203%200%201%200-3%203h12a3%203%200%201%200-3-3%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "corner-down-right": "%3Csvg%20class%3D%22lucide%20lucide-corner-down-right%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22m15%2010%205%205-5%205%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M4%204v7a4%204%200%200%200%204%204h12%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "download": "%3Csvg%20class%3D%22lucide%20lucide-download%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M12%2015V3%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M21%2015v4a2%202%200%200%201-2%202H5a2%202%200%200%201-2-2v-4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22m7%2010%205%205%205-5%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "ellipsis": "%3Csvg%20class%3D%22lucide%20lucide-ellipsis%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%221%22%3E%3C%2Fcircle%3E%20%3Ccircle%20cx%3D%2219%22%20cy%3D%2212%22%20r%3D%221%22%3E%3C%2Fcircle%3E%20%3Ccircle%20cx%3D%225%22%20cy%3D%2212%22%20r%3D%221%22%3E%3C%2Fcircle%3E%20%3C%2Fsvg%3E",
  "file-check-2": "%3Csvg%20class%3D%22lucide%20lucide-file-check-2%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M4%2022h14a2%202%200%200%200%202-2V7l-5-5H6a2%202%200%200%200-2%202v4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M14%202v4a2%202%200%200%200%202%202h4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22m3%2015%202%202%204-4%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "file-text": "%3Csvg%20class%3D%22lucide%20lucide-file-text%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M15%202H6a2%202%200%200%200-2%202v16a2%202%200%200%200%202%202h12a2%202%200%200%200%202-2V7Z%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M14%202v4a2%202%200%200%200%202%202h4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M10%209H8%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M16%2013H8%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M16%2017H8%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "filter": "%3Csvg%20class%3D%22lucide%20lucide-filter%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M10%2020a1%201%200%200%200%20.553.895l2%201A1%201%200%200%200%2014%2021v-7a2%202%200%200%201%20.517-1.341L21.74%204.67A1%201%200%200%200%2021%203H3a1%201%200%200%200-.742%201.67l7.225%207.989A2%202%200%200%201%2010%2014z%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "flask-conical": "%3Csvg%20class%3D%22lucide%20lucide-flask-conical%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M14%202v6a2%202%200%200%200%20.245.96l5.51%2010.08A2%202%200%200%201%2018%2022H6a2%202%200%200%201-1.755-2.96l5.51-10.08A2%202%200%200%200%2010%208V2%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M6.453%2015h11.094%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M8.5%202h7%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "gantt-chart": "%3Csvg%20class%3D%22lucide%20lucide-gantt-chart%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M6%205h12%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M4%2012h10%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M12%2019h8%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "git-branch": "%3Csvg%20class%3D%22lucide%20lucide-git-branch%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cline%20x1%3D%226%22%20x2%3D%226%22%20y1%3D%223%22%20y2%3D%2215%22%3E%3C%2Fline%3E%20%3Ccircle%20cx%3D%2218%22%20cy%3D%226%22%20r%3D%223%22%3E%3C%2Fcircle%3E%20%3Ccircle%20cx%3D%226%22%20cy%3D%2218%22%20r%3D%223%22%3E%3C%2Fcircle%3E%20%3Cpath%20d%3D%22M18%209a9%209%200%200%201-9%209%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "git-compare": "%3Csvg%20class%3D%22lucide%20lucide-git-compare%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Ccircle%20cx%3D%2218%22%20cy%3D%2218%22%20r%3D%223%22%3E%3C%2Fcircle%3E%20%3Ccircle%20cx%3D%226%22%20cy%3D%226%22%20r%3D%223%22%3E%3C%2Fcircle%3E%20%3Cpath%20d%3D%22M13%206h3a2%202%200%200%201%202%202v7%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M11%2018H8a2%202%200%200%201-2-2V9%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "group": "%3Csvg%20class%3D%22lucide%20lucide-group%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M3%207V5c0-1.1.9-2%202-2h2%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M17%203h2c1.1%200%202%20.9%202%202v2%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M21%2017v2c0%201.1-.9%202-2%202h-2%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M7%2021H5c-1.1%200-2-.9-2-2v-2%22%3E%3C%2Fpath%3E%20%3Crect%20width%3D%227%22%20height%3D%225%22%20x%3D%227%22%20y%3D%227%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3Crect%20width%3D%227%22%20height%3D%225%22%20x%3D%2210%22%20y%3D%2212%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3C%2Fsvg%3E",
  "inbox": "%3Csvg%20class%3D%22lucide%20lucide-inbox%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpolyline%20points%3D%2222%2012%2016%2012%2014%2015%2010%2015%208%2012%202%2012%22%3E%3C%2Fpolyline%3E%20%3Cpath%20d%3D%22M5.45%205.11%202%2012v6a2%202%200%200%200%202%202h16a2%202%200%200%200%202-2v-6l-3.45-6.89A2%202%200%200%200%2016.76%204H7.24a2%202%200%200%200-1.79%201.11z%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "info": "%3Csvg%20class%3D%22lucide%20lucide-info%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%2210%22%3E%3C%2Fcircle%3E%20%3Cpath%20d%3D%22M12%2016v-4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M12%208h.01%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "layout-dashboard": "%3Csvg%20class%3D%22lucide%20lucide-layout-dashboard%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Crect%20width%3D%227%22%20height%3D%229%22%20x%3D%223%22%20y%3D%223%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3Crect%20width%3D%227%22%20height%3D%225%22%20x%3D%2214%22%20y%3D%223%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3Crect%20width%3D%227%22%20height%3D%229%22%20x%3D%2214%22%20y%3D%2212%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3Crect%20width%3D%227%22%20height%3D%225%22%20x%3D%223%22%20y%3D%2216%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3C%2Fsvg%3E",
  "layout-grid": "%3Csvg%20class%3D%22lucide%20lucide-layout-grid%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Crect%20width%3D%227%22%20height%3D%227%22%20x%3D%223%22%20y%3D%223%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3Crect%20width%3D%227%22%20height%3D%227%22%20x%3D%2214%22%20y%3D%223%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3Crect%20width%3D%227%22%20height%3D%227%22%20x%3D%2214%22%20y%3D%2214%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3Crect%20width%3D%227%22%20height%3D%227%22%20x%3D%223%22%20y%3D%2214%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3C%2Fsvg%3E",
  "link": "%3Csvg%20class%3D%22lucide%20lucide-link%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M10%2013a5%205%200%200%200%207.54.54l3-3a5%205%200%200%200-7.07-7.07l-1.72%201.71%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M14%2011a5%205%200%200%200-7.54-.54l-3%203a5%205%200%200%200%207.07%207.07l1.71-1.71%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "list-checks": "%3Csvg%20class%3D%22lucide%20lucide-list-checks%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M13%205h8%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M13%2012h8%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M13%2019h8%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22m3%2017%202%202%204-4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22m3%207%202%202%204-4%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "list": "%3Csvg%20class%3D%22lucide%20lucide-list%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M3%205h.01%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M3%2012h.01%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M3%2019h.01%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M8%205h13%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M8%2012h13%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M8%2019h13%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "loader-circle": "%3Csvg%20class%3D%22lucide%20lucide-loader-circle%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M21%2012a9%209%200%201%201-6.219-8.56%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "message-square": "%3Csvg%20class%3D%22lucide%20lucide-message-square%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M22%2017a2%202%200%200%201-2%202H6.828a2%202%200%200%200-1.414.586l-2.202%202.202A.71.71%200%200%201%202%2021.286V5a2%202%200%200%201%202-2h16a2%202%200%200%201%202%202z%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "minus": "%3Csvg%20class%3D%22lucide%20lucide-minus%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M5%2012h14%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "paperclip": "%3Csvg%20class%3D%22lucide%20lucide-paperclip%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22m16%206-8.414%208.586a2%202%200%200%200%202.829%202.829l8.414-8.586a4%204%200%201%200-5.657-5.657l-8.379%208.551a6%206%200%201%200%208.485%208.485l8.379-8.551%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "pause": "%3Csvg%20class%3D%22lucide%20lucide-pause%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Crect%20x%3D%2214%22%20y%3D%223%22%20width%3D%225%22%20height%3D%2218%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3Crect%20x%3D%225%22%20y%3D%223%22%20width%3D%225%22%20height%3D%2218%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3C%2Fsvg%3E",
  "pen-square": "%3Csvg%20class%3D%22lucide%20lucide-pen-square%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M12%203H5a2%202%200%200%200-2%202v14a2%202%200%200%200%202%202h14a2%202%200%200%200%202-2v-7%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M18.375%202.625a1%201%200%200%201%203%203l-9.013%209.014a2%202%200%200%201-.853.505l-2.873.84a.5.5%200%200%201-.62-.62l.84-2.873a2%202%200%200%201%20.506-.852z%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "play": "%3Csvg%20class%3D%22lucide%20lucide-play%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M5%205a2%202%200%200%201%203.008-1.728l11.997%206.998a2%202%200%200%201%20.003%203.458l-12%207A2%202%200%200%201%205%2019z%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "plus": "%3Csvg%20class%3D%22lucide%20lucide-plus%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M5%2012h14%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M12%205v14%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "refresh-cw": "%3Csvg%20class%3D%22lucide%20lucide-refresh-cw%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M3%2012a9%209%200%200%201%209-9%209.75%209.75%200%200%201%206.74%202.74L21%208%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M21%203v5h-5%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M21%2012a9%209%200%200%201-9%209%209.75%209.75%200%200%201-6.74-2.74L3%2016%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M8%2016H3v5%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "search": "%3Csvg%20class%3D%22lucide%20lucide-search%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22m21%2021-4.34-4.34%22%3E%3C%2Fpath%3E%20%3Ccircle%20cx%3D%2211%22%20cy%3D%2211%22%20r%3D%228%22%3E%3C%2Fcircle%3E%20%3C%2Fsvg%3E",
  "settings": "%3Csvg%20class%3D%22lucide%20lucide-settings%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M9.671%204.136a2.34%202.34%200%200%201%204.659%200%202.34%202.34%200%200%200%203.319%201.915%202.34%202.34%200%200%201%202.33%204.033%202.34%202.34%200%200%200%200%203.831%202.34%202.34%200%200%201-2.33%204.033%202.34%202.34%200%200%200-3.319%201.915%202.34%202.34%200%200%201-4.659%200%202.34%202.34%200%200%200-3.32-1.915%202.34%202.34%200%200%201-2.33-4.033%202.34%202.34%200%200%200%200-3.831A2.34%202.34%200%200%201%206.35%206.051a2.34%202.34%200%200%200%203.319-1.915%22%3E%3C%2Fpath%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%223%22%3E%3C%2Fcircle%3E%20%3C%2Fsvg%3E",
  "shapes": "%3Csvg%20class%3D%22lucide%20lucide-shapes%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M8.3%2010a.7.7%200%200%201-.626-1.079L11.4%203a.7.7%200%200%201%201.198-.043L16.3%208.9a.7.7%200%200%201-.572%201.1Z%22%3E%3C%2Fpath%3E%20%3Crect%20x%3D%223%22%20y%3D%2214%22%20width%3D%227%22%20height%3D%227%22%20rx%3D%221%22%3E%3C%2Frect%3E%20%3Ccircle%20cx%3D%2217.5%22%20cy%3D%2217.5%22%20r%3D%223.5%22%3E%3C%2Fcircle%3E%20%3C%2Fsvg%3E",
  "shield-check": "%3Csvg%20class%3D%22lucide%20lucide-shield-check%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M20%2013c0%205-3.5%207.5-7.66%208.95a1%201%200%200%201-.67-.01C7.5%2020.5%204%2018%204%2013V6a1%201%200%200%201%201-1c2%200%204.5-1.2%206.24-2.72a1.17%201.17%200%200%201%201.52%200C14.51%203.81%2017%205%2019%205a1%201%200%200%201%201%201z%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22m9%2012%202%202%204-4%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "signal-high": "%3Csvg%20class%3D%22lucide%20lucide-signal-high%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M2%2020h.01%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M7%2020v-4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M12%2020v-8%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M17%2020V8%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "signal-low": "%3Csvg%20class%3D%22lucide%20lucide-signal-low%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M2%2020h.01%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M7%2020v-4%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "signal-medium": "%3Csvg%20class%3D%22lucide%20lucide-signal-medium%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M2%2020h.01%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M7%2020v-4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M12%2020v-8%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "sparkles": "%3Csvg%20class%3D%22lucide%20lucide-sparkles%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M11.017%202.814a1%201%200%200%201%201.966%200l1.051%205.558a2%202%200%200%200%201.594%201.594l5.558%201.051a1%201%200%200%201%200%201.966l-5.558%201.051a2%202%200%200%200-1.594%201.594l-1.051%205.558a1%201%200%200%201-1.966%200l-1.051-5.558a2%202%200%200%200-1.594-1.594l-5.558-1.051a1%201%200%200%201%200-1.966l5.558-1.051a2%202%200%200%200%201.594-1.594z%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M20%202v4%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M22%204h-4%22%3E%3C%2Fpath%3E%20%3Ccircle%20cx%3D%224%22%20cy%3D%2220%22%20r%3D%222%22%3E%3C%2Fcircle%3E%20%3C%2Fsvg%3E",
  "terminal": "%3Csvg%20class%3D%22lucide%20lucide-terminal%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M12%2019h8%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22m4%2017%206-6-6-6%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "trash-2": "%3Csvg%20class%3D%22lucide%20lucide-trash-2%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M10%2011v6%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M14%2011v6%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M19%206v14a2%202%200%200%201-2%202H7a2%202%200%200%201-2-2V6%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M3%206h18%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M8%206V4a2%202%200%200%201%202-2h4a2%202%200%200%201%202%202v2%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "undo-2": "%3Csvg%20class%3D%22lucide%20lucide-undo-2%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M9%2014%204%209l5-5%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22M4%209h10.5a5.5%205.5%200%200%201%205.5%205.5a5.5%205.5%200%200%201-5.5%205.5H11%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E",
  "user": "%3Csvg%20class%3D%22lucide%20lucide-user%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M19%2021v-2a4%204%200%200%200-4-4H9a4%204%200%200%200-4%204v2%22%3E%3C%2Fpath%3E%20%3Ccircle%20cx%3D%2212%22%20cy%3D%227%22%20r%3D%224%22%3E%3C%2Fcircle%3E%20%3C%2Fsvg%3E",
  "x": "%3Csvg%20class%3D%22lucide%20lucide-x%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22currentColor%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%20%3Cpath%20d%3D%22M18%206%206%2018%22%3E%3C%2Fpath%3E%20%3Cpath%20d%3D%22m6%206%2012%2012%22%3E%3C%2Fpath%3E%20%3C%2Fsvg%3E"
};
function Icon({
  name,
  size = 16,
  style,
  className,
  ...rest
}) {
  const g = GLYPHS[name];
  const url = g ? 'url("data:image/svg+xml,' + g + '")' : 'none';
  return /*#__PURE__*/React.createElement("span", _extends({
    "aria-hidden": "true",
    "data-icon": name,
    className: className,
    style: {
      display: 'inline-block',
      flex: 'none',
      width: size,
      height: size,
      background: 'currentColor',
      WebkitMaskImage: url,
      maskImage: url,
      WebkitMaskSize: 'contain',
      maskSize: 'contain',
      WebkitMaskRepeat: 'no-repeat',
      maskRepeat: 'no-repeat',
      WebkitMaskPosition: 'center',
      maskPosition: 'center',
      ...style
    }
  }, rest));
}
const ICON_NAMES = Object.keys(GLYPHS);
Object.assign(__ds_scope, { Icon, ICON_NAMES });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  xs: 18,
  sm: 22,
  md: 28,
  lg: 36
};

/* kind="agent" renders the ember-ringed AI identity; kind="user" renders initials or a photo. */
function Avatar({
  name = '',
  src,
  kind = 'user',
  size = 'md',
  status,
  style,
  ...rest
}) {
  const px = SIZES[size] || SIZES.md;
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  const agent = kind === 'agent';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: 'relative',
      display: 'inline-flex',
      flex: 'none',
      ...style
    },
    title: name
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: px,
      height: px,
      borderRadius: agent ? 'var(--radius-sm)' : 'var(--radius-full)',
      overflow: 'hidden',
      background: agent ? 'var(--agent-bg)' : 'var(--gray-100)',
      border: '1px solid ' + (agent ? 'var(--agent-border)' : 'var(--border-default)'),
      color: agent ? 'var(--agent-fg)' : 'var(--text-secondary)',
      fontFamily: 'var(--font-sans)',
      fontSize: Math.round(px * .38),
      fontWeight: 'var(--weight-semibold)'
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : agent ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "sparkles",
    size: Math.round(px * .55)
  }) : initials), status ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: -1,
      bottom: -1,
      width: Math.max(7, px * .28),
      height: Math.max(7, px * .28),
      borderRadius: 999,
      background: 'var(--status-' + status + ')',
      border: '2px solid var(--surface-card)'
    }
  }) : null);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  neutral: ['var(--surface-sunken)', 'var(--text-secondary)', 'var(--border-default)'],
  accent: ['var(--accent-soft)', 'var(--text-accent)', 'var(--accent-soft-border)'],
  success: ['var(--success-bg)', 'var(--success-fg)', 'transparent'],
  warning: ['var(--warning-bg)', 'var(--warning-fg)', 'transparent'],
  danger: ['var(--danger-bg)', 'var(--danger-fg)', 'transparent'],
  info: ['var(--info-bg)', 'var(--info-fg)', 'transparent'],
  solid: ['var(--accent-solid)', 'var(--accent-on-solid)', 'transparent']
};
function Badge({
  children,
  tone = 'neutral',
  icon,
  dot = false,
  size = 'md',
  style,
  ...rest
}) {
  const [bg, fg, bd] = TONES[tone] || TONES.neutral;
  const sm = size === 'sm';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: sm ? 4 : 5,
      height: sm ? 18 : 22,
      padding: sm ? '0 6px' : '0 8px',
      background: bg,
      color: fg,
      border: '1px solid ' + bd,
      borderRadius: 'var(--radius-full)',
      fontFamily: 'var(--font-sans)',
      fontSize: sm ? 'var(--text-2xs)' : 'var(--text-xs)',
      fontWeight: 'var(--weight-medium)',
      letterSpacing: 'var(--tracking-tight)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), dot ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 5,
      height: 5,
      borderRadius: 999,
      background: 'currentColor'
    }
  }) : null, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: sm ? 11 : 12
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    height: 'var(--control-height-sm)',
    padding: '0 8px',
    font: 'var(--text-xs)',
    gap: 5,
    icon: 13
  },
  md: {
    height: 'var(--control-height-md)',
    padding: '0 11px',
    font: 'var(--text-sm)',
    gap: 6,
    icon: 15
  },
  lg: {
    height: 'var(--control-height-lg)',
    padding: '0 15px',
    font: 'var(--text-md)',
    gap: 7,
    icon: 16
  }
};
const VARIANTS = {
  primary: {
    background: 'var(--accent-solid)',
    color: 'var(--accent-on-solid)',
    border: '1px solid transparent',
    boxShadow: 'var(--shadow-xs)'
  },
  secondary: {
    background: 'var(--surface-card)',
    color: 'var(--text-primary)',
    border: '1px solid var(--border-default)',
    boxShadow: 'var(--shadow-xs)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--text-secondary)',
    border: '1px solid transparent'
  },
  danger: {
    background: 'var(--danger-solid)',
    color: '#fff',
    border: '1px solid transparent'
  },
  inverse: {
    background: 'var(--surface-inverse)',
    color: 'var(--text-inverse)',
    border: '1px solid transparent'
  }
};
const HOVER = {
  primary: {
    background: 'var(--accent-solid-hover)'
  },
  secondary: {
    background: 'var(--surface-hover)'
  },
  ghost: {
    background: 'var(--surface-hover)',
    color: 'var(--text-primary)'
  },
  danger: {
    background: 'var(--red-600)'
  },
  inverse: {
    opacity: .88
  }
};
function Button({
  children,
  variant = 'secondary',
  size = 'md',
  icon,
  iconEnd,
  loading = false,
  disabled = false,
  fullWidth = false,
  onClick,
  type = 'button',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [down, setDown] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.secondary;
  const off = disabled || loading;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: off,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setDown(false);
    },
    onMouseDown: () => setDown(true),
    onMouseUp: () => setDown(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      height: s.height,
      padding: s.padding,
      width: fullWidth ? '100%' : undefined,
      fontFamily: 'var(--font-sans)',
      fontSize: s.font,
      fontWeight: 'var(--weight-medium)',
      letterSpacing: 'var(--tracking-tight)',
      borderRadius: 'var(--radius-md)',
      cursor: off ? 'not-allowed' : 'pointer',
      opacity: off ? .45 : 1,
      transition: 'var(--transition-control), transform var(--duration-instant) var(--ease-standard)',
      transform: down && !off ? 'scale(.985)' : 'none',
      ...v,
      ...(hover && !off ? HOVER[variant] : null),
      ...style
    }
  }, rest), loading ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "loader-circle",
    size: s.icon,
    style: {
      animation: 'forge-spin 900ms linear infinite'
    }
  }) : icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: s.icon
  }) : null, children, iconEnd ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconEnd,
    size: s.icon
  }) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: [26, 14],
  md: [32, 16],
  lg: [38, 18]
};
function IconButton({
  icon,
  size = 'md',
  variant = 'ghost',
  active = false,
  disabled = false,
  label,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [box, glyph] = SIZES[size] || SIZES.md;
  const base = variant === 'secondary' ? {
    background: 'var(--surface-card)',
    border: '1px solid var(--border-default)'
  } : {
    background: 'transparent',
    border: '1px solid transparent'
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: box,
      height: box,
      borderRadius: 'var(--radius-md)',
      flex: 'none',
      color: active ? 'var(--text-accent)' : 'var(--text-secondary)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .45 : 1,
      transition: 'var(--transition-control)',
      ...base,
      ...(active ? {
        background: 'var(--surface-selected)'
      } : null),
      ...(hover && !disabled ? {
        background: 'var(--surface-hover)',
        color: 'var(--text-primary)'
      } : null),
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: glyph
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Kbd.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Forge is keyboard-first; shortcuts are shown inline everywhere. */
function Kbd({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("kbd", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      minWidth: 18,
      height: 18,
      padding: '0 4px',
      background: 'var(--surface-sunken)',
      border: '1px solid var(--border-default)',
      borderBottomWidth: 2,
      borderRadius: 'var(--radius-xs)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-tertiary)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Kbd });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Kbd.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tag({
  children,
  color = 'var(--gray-400)',
  onRemove,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      height: 20,
      padding: '0 7px',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-sm)',
      color: 'var(--text-secondary)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--weight-medium)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 2,
      background: color
    }
  }), children, onRemove ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onRemove,
    "aria-label": "Remove",
    style: {
      display: 'flex',
      border: 0,
      background: 'none',
      padding: 0,
      marginRight: -2,
      color: 'var(--text-tertiary)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 11
  })) : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open = true,
  title,
  description,
  children,
  footer,
  width = 460,
  onClose
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 60,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--surface-overlay)',
      backdropFilter: 'var(--blur-overlay)',
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width,
      maxWidth: '100%',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-xl)',
      animation: 'forge-rise var(--duration-normal) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12,
      padding: '16px 16px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-h3)',
      color: 'var(--text-primary)',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, title), description ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-caption)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      marginTop: 4
    }
  }, description) : null), onClose ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    size: "sm",
    label: "Close",
    onClick: onClose
  }) : null), children ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 16px'
    }
  }, children) : /*#__PURE__*/React.createElement("div", {
    style: {
      height: 14
    }
  }), footer ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 8,
      padding: '12px 16px',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, footer) : null));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/EmptyState.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function EmptyState({
  icon = 'inbox',
  title,
  description,
  action,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 6,
      padding: '48px 24px',
      textAlign: 'center',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 34,
      height: 34,
      marginBottom: 4,
      borderRadius: 'var(--radius-lg)',
      background: 'var(--surface-sunken)',
      border: '1px solid var(--border-subtle)',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 17
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-h3)',
      fontSize: 'var(--text-md)',
      color: 'var(--text-primary)'
    }
  }, title), description ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-caption)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-tertiary)',
      maxWidth: 320
    }
  }, description) : null, action ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, action) : null);
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/feedback/ProgressBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ProgressBar({
  value = 0,
  tone = 'accent',
  size = 'md',
  indeterminate = false,
  label,
  style,
  ...rest
}) {
  const h = size === 'sm' ? 3 : size === 'lg' ? 8 : 5;
  const color = tone === 'accent' ? 'var(--accent-solid)' : 'var(--status-' + tone + ')';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 5,
      ...style
    }
  }, rest), label ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement("span", null, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)'
    }
  }, Math.round(value), "%")) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      height: h,
      borderRadius: 999,
      background: 'var(--gray-200)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: indeterminate ? {
      height: '100%',
      width: '100%',
      borderRadius: 999,
      background: 'linear-gradient(90deg,transparent,' + color + ',transparent)',
      backgroundSize: '200% 100%',
      animation: 'forge-scan 1.4s linear infinite'
    } : {
      height: '100%',
      width: Math.max(0, Math.min(100, value)) + '%',
      borderRadius: 999,
      background: color,
      transition: 'width var(--duration-slow) var(--ease-out)'
    }
  })));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  neutral: ['info', 'var(--text-secondary)'],
  success: ['circle-check', 'var(--success-fg)'],
  danger: ['circle-alert', 'var(--danger-fg)'],
  agent: ['sparkles', 'var(--agent-fg)']
};
function Toast({
  title,
  description,
  tone = 'neutral',
  action,
  onDismiss,
  style,
  ...rest
}) {
  const [icon, color] = TONES[tone] || TONES.neutral;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'flex-start',
      width: 340,
      padding: '10px 10px 10px 12px',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-lg)',
      animation: 'forge-rise var(--duration-normal) var(--ease-out)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 15,
    style: {
      color,
      marginTop: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-primary)'
    }
  }, title), description ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-secondary)',
      marginTop: 2
    }
  }, description) : null, action ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, action) : null), onDismiss ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    size: "sm",
    label: "Dismiss",
    onClick: onDismiss
  }) : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tooltip({
  children,
  content,
  shortcut,
  side = 'top',
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const pos = {
    top: {
      bottom: '100%',
      left: '50%',
      transform: 'translate(-50%,-6px)'
    },
    bottom: {
      top: '100%',
      left: '50%',
      transform: 'translate(-50%,6px)'
    },
    right: {
      left: '100%',
      top: '50%',
      transform: 'translate(6px,-50%)'
    },
    left: {
      right: '100%',
      top: '50%',
      transform: 'translate(-6px,-50%)'
    }
  }[side];
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    },
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false)
  }, rest), children, open ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      zIndex: 40,
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      padding: '4px 7px',
      background: 'var(--surface-inverse)',
      color: 'var(--text-inverse)',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-lg)',
      font: 'var(--type-caption)',
      whiteSpace: 'nowrap',
      pointerEvents: 'none',
      animation: 'forge-rise var(--duration-fast) var(--ease-out)',
      ...pos
    }
  }, content, shortcut ? /*#__PURE__*/React.createElement(__ds_scope.Kbd, {
    style: {
      background: 'rgba(255,255,255,.12)',
      borderColor: 'rgba(255,255,255,.2)',
      color: 'inherit'
    }
  }, shortcut) : null) : null);
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  checked = false,
  indeterminate = false,
  onChange,
  label,
  description,
  disabled,
  style,
  ...rest
}) {
  const on = checked || indeterminate;
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'flex',
      gap: 8,
      alignItems: description ? 'flex-start' : 'center',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 'none',
      width: 16,
      height: 16,
      marginTop: description ? 1 : 0,
      borderRadius: 'var(--radius-xs)',
      background: on ? 'var(--accent-solid)' : 'var(--surface-card)',
      border: '1px solid ' + (on ? 'var(--accent-solid)' : 'var(--border-strong)'),
      color: '#fff',
      transition: 'var(--transition-control)'
    }
  }, indeterminate ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "minus",
    size: 11
  }) : checked ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 11
  }) : null), label || description ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 1
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      fontWeight: 'var(--weight-regular)',
      color: 'var(--text-body)'
    }
  }, label) : null, description ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, description) : null) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  icon,
  suffix,
  size = 'md',
  disabled,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const h = size === 'sm' ? 'var(--control-height-sm)' : size === 'lg' ? 'var(--control-height-lg)' : 'var(--control-height-md)';
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 5,
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-body)'
    }
  }, label) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      height: h,
      padding: '0 9px',
      background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
      border: '1px solid ' + (error ? 'var(--danger-solid)' : focus ? 'var(--border-focus)' : 'var(--border-default)'),
      borderRadius: 'var(--radius-md)',
      boxShadow: focus ? 'var(--focus-ring)' : 'none',
      transition: 'var(--transition-control)'
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14,
    style: {
      color: 'var(--text-tertiary)'
    }
  }) : null, /*#__PURE__*/React.createElement("input", _extends({
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 'none',
      background: 'transparent',
      font: 'var(--type-body)',
      fontSize: size === 'sm' ? 'var(--text-xs)' : 'var(--text-sm)',
      color: 'var(--text-primary)'
    }
  }, rest)), suffix ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, suffix) : null), error || hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: error ? 'var(--danger-fg)' : 'var(--text-tertiary)'
    }
  }, error || hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  checked = false,
  onChange,
  label,
  description,
  disabled,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'flex',
      gap: 8,
      alignItems: description ? 'flex-start' : 'center',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(true),
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 'none',
      width: 16,
      height: 16,
      marginTop: description ? 1 : 0,
      borderRadius: 'var(--radius-full)',
      background: 'var(--surface-card)',
      border: '1px solid ' + (checked ? 'var(--accent-solid)' : 'var(--border-strong)'),
      transition: 'var(--transition-control)'
    }
  }, checked ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: 999,
      background: 'var(--accent-solid)'
    }
  }) : null), label || description ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 1
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      fontWeight: 'var(--weight-regular)',
      color: 'var(--text-body)'
    }
  }, label) : null, description ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, description) : null) : null);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  options = [],
  value,
  onChange,
  size = 'md',
  disabled,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const h = size === 'sm' ? 'var(--control-height-sm)' : 'var(--control-height-md)';
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 5,
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-body)'
    }
  }, label) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      height: h,
      background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
      border: '1px solid ' + (focus ? 'var(--border-focus)' : 'var(--border-default)'),
      borderRadius: 'var(--radius-md)',
      boxShadow: focus ? 'var(--focus-ring)' : 'none',
      transition: 'var(--transition-control)'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    value: value,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.value),
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: 'none',
      width: '100%',
      height: '100%',
      padding: '0 28px 0 9px',
      border: 0,
      outline: 'none',
      background: 'transparent',
      cursor: disabled ? 'not-allowed' : 'pointer',
      font: 'var(--type-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-primary)'
    }
  }, rest), options.map(o => {
    const opt = typeof o === 'string' ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  })), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 14,
    style: {
      position: 'absolute',
      right: 8,
      color: 'var(--text-tertiary)',
      pointerEvents: 'none'
    }
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  checked = false,
  onChange,
  label,
  size = 'md',
  disabled,
  style,
  ...rest
}) {
  const w = size === 'sm' ? 26 : 32,
    h = size === 'sm' ? 15 : 18,
    k = h - 4;
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      position: 'relative',
      width: w,
      height: h,
      flex: 'none',
      borderRadius: 999,
      background: checked ? 'var(--accent-solid)' : 'var(--gray-300)',
      transition: 'background-color var(--duration-normal) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 2,
      left: checked ? w - k - 2 : 2,
      width: k,
      height: k,
      borderRadius: 999,
      background: '#fff',
      boxShadow: '0 1px 2px rgba(0,0,0,.2)',
      transition: 'left var(--duration-normal) var(--ease-out)'
    }
  })), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      fontWeight: 'var(--weight-regular)',
      color: 'var(--text-body)'
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Textarea({
  label,
  hint,
  rows = 4,
  disabled,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 5,
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-body)'
    }
  }, label) : null, /*#__PURE__*/React.createElement("textarea", _extends({
    rows: rows,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      resize: 'vertical',
      padding: '8px 9px',
      background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
      border: '1px solid ' + (focus ? 'var(--border-focus)' : 'var(--border-default)'),
      borderRadius: 'var(--radius-md)',
      boxShadow: focus ? 'var(--focus-ring)' : 'none',
      outline: 'none',
      font: 'var(--type-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-primary)',
      transition: 'var(--transition-control)'
    }
  }, rest)), hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumbs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Breadcrumbs({
  items = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      ...style
    }
  }, rest), items.map((it, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 13,
    style: {
      color: 'var(--text-disabled)'
    }
  }) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      font: 'var(--type-ui)',
      color: i === items.length - 1 ? 'var(--text-primary)' : 'var(--text-tertiary)',
      cursor: it.onClick ? 'pointer' : 'default'
    },
    onClick: it.onClick
  }, it.icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: it.icon,
    size: 13
  }) : null, it.label))));
}
Object.assign(__ds_scope, { Breadcrumbs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumbs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SidebarItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SidebarItem({
  icon,
  label,
  active = false,
  count,
  indent = 0,
  dot,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      width: '100%',
      height: 28,
      padding: '0 8px 0 ' + (8 + indent * 14) + 'px',
      border: 0,
      textAlign: 'left',
      background: active ? 'var(--surface-active)' : hover ? 'var(--surface-hover)' : 'transparent',
      borderRadius: 'var(--radius-sm)',
      cursor: 'pointer',
      font: 'var(--type-ui)',
      color: active ? 'var(--text-primary)' : 'var(--text-secondary)',
      transition: 'var(--transition-control)',
      ...style
    }
  }, rest), dot ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 2,
      background: dot,
      flex: 'none'
    }
  }) : icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14,
    style: {
      color: active ? 'var(--text-accent)' : 'var(--text-tertiary)'
    }
  }) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, label), count != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-tertiary)'
    }
  }, count) : null);
}
Object.assign(__ds_scope, { SidebarItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SidebarItem.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tabs({
  tabs = [],
  value,
  onChange,
  variant = 'underline',
  style,
  ...rest
}) {
  const active = value != null ? value : tabs[0] && tabs[0].value;
  const pill = variant === 'pill';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: pill ? 2 : 2,
      padding: pill ? 2 : 0,
      background: pill ? 'var(--surface-sunken)' : 'transparent',
      border: pill ? '1px solid var(--border-subtle)' : 0,
      borderBottom: pill ? '1px solid var(--border-subtle)' : '1px solid var(--border-default)',
      borderRadius: pill ? 'var(--radius-md)' : 0,
      ...style
    }
  }, rest), tabs.map(t => {
    const on = t.value === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t.value,
      type: "button",
      onClick: () => onChange && onChange(t.value),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        height: pill ? 24 : 30,
        padding: pill ? '0 9px' : '0 8px',
        border: 0,
        background: on && pill ? 'var(--surface-card)' : 'transparent',
        borderRadius: pill ? 'var(--radius-sm)' : 0,
        boxShadow: on && pill ? 'var(--shadow-xs)' : 'none',
        borderBottom: pill ? 'none' : '2px solid ' + (on ? 'var(--accent-solid)' : 'transparent'),
        marginBottom: pill ? 0 : -1,
        cursor: 'pointer',
        font: 'var(--type-ui)',
        color: on ? 'var(--text-primary)' : 'var(--text-tertiary)',
        transition: 'var(--transition-control)'
      }
    }, t.icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: t.icon,
      size: 14
    }) : null, t.label, t.count != null ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-2xs)',
        color: 'var(--text-tertiary)'
      }
    }, t.count) : null);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/product/AgentRunIndicator.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Shows that an AI agent is actively executing — the one place the ember accent animates. */
function AgentRunIndicator({
  agent = 'Agent',
  step,
  elapsed,
  state = 'running',
  compact = false,
  style,
  ...rest
}) {
  const running = state === 'running';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      height: compact ? 20 : 24,
      padding: compact ? '0 7px' : '0 9px',
      background: 'var(--agent-bg)',
      border: '1px solid var(--agent-border)',
      borderRadius: 'var(--radius-full)',
      color: 'var(--agent-fg)',
      font: 'var(--type-ui)',
      fontSize: compact ? 'var(--text-2xs)' : 'var(--text-xs)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'flex',
      width: 6,
      height: 6
    }
  }, running ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: -3,
      borderRadius: 999,
      background: 'var(--agent-pulse)',
      animation: 'forge-pulse var(--duration-pulse) var(--ease-standard) infinite'
    }
  }) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: 'currentColor'
    }
  })), agent, step ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)',
      fontWeight: 'var(--weight-regular)'
    }
  }, step) : null, elapsed ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-tertiary)'
    }
  }, elapsed) : null, state === 'paused' ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "pause",
    size: 11
  }) : null);
}
Object.assign(__ds_scope, { AgentRunIndicator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/AgentRunIndicator.jsx", error: String((e && e.message) || e) }); }

// components/product/ApprovalBanner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Human checkpoint. Appears inline above the work it gates — never as a modal. */
function ApprovalBanner({
  title,
  description,
  actions,
  tone = 'accent',
  style,
  ...rest
}) {
  const bg = tone === 'accent' ? 'var(--accent-soft)' : 'var(--warning-bg)';
  const bd = tone === 'accent' ? 'var(--accent-soft-border)' : 'transparent';
  const fg = tone === 'accent' ? 'var(--text-accent)' : 'var(--warning-fg)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 11,
      padding: '11px 12px',
      background: bg,
      border: '1px solid ' + bd,
      borderRadius: 'var(--radius-lg)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "shield-check",
    size: 16,
    style: {
      color: fg,
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-primary)'
    }
  }, title), description ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-secondary)',
      marginTop: 2
    }
  }, description) : null), actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flex: 'none'
    }
  }, actions) : null);
}
Object.assign(__ds_scope, { ApprovalBanner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/ApprovalBanner.jsx", error: String((e && e.message) || e) }); }

// components/product/ExecutionLog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const LEVEL = {
  tool: 'var(--ember-400)',
  info: 'var(--log-dim)',
  ok: 'var(--green-500)',
  warn: 'var(--amber-500)',
  error: 'var(--red-500)'
};

/* Streaming record of everything an agent did. Monospace, dark, timestamped, never truncated silently. */
function ExecutionLog({
  entries = [],
  live = false,
  height = 240,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--log-surface)',
      borderRadius: 'var(--radius-lg)',
      border: '1px solid var(--border-default)',
      overflow: 'hidden',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      padding: '7px 10px',
      borderBottom: '1px solid rgba(255,255,255,.08)',
      color: 'var(--log-dim)',
      font: 'var(--type-overline)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "terminal",
    size: 12
  }), "Execution log", live ? /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      color: 'var(--ember-400)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 5,
      height: 5,
      borderRadius: 999,
      background: 'currentColor',
      animation: 'forge-pulse var(--duration-pulse) infinite'
    }
  }), "live") : null), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: height,
      overflow: 'auto',
      padding: '8px 10px',
      font: 'var(--type-mono)',
      color: 'var(--log-text)'
    }
  }, entries.map((e, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 10,
      padding: '2px 0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--log-dim)',
      flex: 'none'
    }
  }, e.time), /*#__PURE__*/React.createElement("span", {
    style: {
      color: LEVEL[e.level] || 'var(--log-dim)',
      flex: 'none',
      width: 46
    }
  }, e.level), /*#__PURE__*/React.createElement("span", {
    style: {
      whiteSpace: 'pre-wrap'
    }
  }, e.message)))));
}
Object.assign(__ds_scope, { ExecutionLog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/ExecutionLog.jsx", error: String((e && e.message) || e) }); }

// components/product/StatusPill.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const STATUSES = {
  'open-questions': {
    label: 'Open questions',
    icon: 'circle-help',
    color: 'var(--status-open-questions)'
  },
  design: {
    label: 'Design',
    icon: 'shapes',
    color: 'var(--status-design)'
  },
  ready: {
    label: 'Ready',
    icon: 'circle',
    color: 'var(--status-ready)'
  },
  running: {
    label: 'Running',
    icon: 'loader-circle',
    color: 'var(--status-running)'
  },
  testing: {
    label: 'Testing',
    icon: 'flask-conical',
    color: 'var(--status-testing)'
  },
  reviewing: {
    label: 'Reviewing',
    icon: 'circle-user-round',
    color: 'var(--status-reviewing)'
  },
  paused: {
    label: 'Paused',
    icon: 'circle-pause',
    color: 'var(--status-paused)'
  },
  failed: {
    label: 'Failed',
    icon: 'circle-x',
    color: 'var(--status-failed)'
  },
  canceled: {
    label: 'Canceled',
    icon: 'circle-slash',
    color: 'var(--status-canceled)'
  },
  done: {
    label: 'Done',
    icon: 'circle-check',
    color: 'var(--status-done)'
  }
};

/* The single source of truth for task lifecycle state across every Forge view. */
function StatusPill({
  status = 'ready',
  showLabel = true,
  size = 'md',
  style,
  ...rest
}) {
  const s = STATUSES[status] || STATUSES.ready;
  const px = size === 'sm' ? 12 : 14;
  const spin = status === 'running';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      color: 'var(--text-secondary)',
      font: 'var(--type-ui)',
      fontSize: size === 'sm' ? 'var(--text-xs)' : 'var(--text-sm)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: s.icon,
    size: px,
    style: {
      color: s.color,
      animation: spin ? 'forge-spin 1.6s linear infinite' : undefined
    }
  }), showLabel ? s.label : null);
}
Object.assign(__ds_scope, { STATUSES, StatusPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/StatusPill.jsx", error: String((e && e.message) || e) }); }

// components/product/TaskCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const PRIORITY = {
  urgent: ['signal-high', 'var(--danger-fg)'],
  high: ['signal-high', 'var(--warning-fg)'],
  medium: ['signal-medium', 'var(--text-tertiary)'],
  low: ['signal-low', 'var(--text-disabled)']
};

/* The Kanban/list unit of work. Agent-run tasks show live progress instead of a static assignee. */
function TaskCard({
  id,
  title,
  status = 'ready',
  priority = 'medium',
  labels = [],
  assignee,
  agent,
  progress,
  due,
  comments,
  attachments,
  selected = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [pIcon, pColor] = PRIORITY[priority] || PRIORITY.medium;
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      padding: 10,
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-lg)',
      border: '1px solid ' + (selected ? 'var(--border-accent)' : 'var(--border-default)'),
      boxShadow: hover ? 'var(--shadow-md)' : 'var(--shadow-xs)',
      cursor: 'pointer',
      transition: 'box-shadow var(--duration-normal) var(--ease-standard), border-color var(--duration-fast) var(--ease-standard)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-disabled)'
    }
  }, id), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: pIcon,
    size: 13,
    style: {
      color: pColor
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-ui)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-primary)',
      lineHeight: 1.35
    }
  }, title), agent && progress != null ? /*#__PURE__*/React.createElement(__ds_scope.ProgressBar, {
    value: progress,
    size: "sm"
  }) : null, labels.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 4
    }
  }, labels.map(l => /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    key: l.name,
    color: l.color
  }, l.name))) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 1
    }
  }, agent ? /*#__PURE__*/React.createElement(__ds_scope.AgentRunIndicator, {
    agent: agent,
    compact: true,
    state: status === 'running' ? 'running' : 'idle'
  }) : /*#__PURE__*/React.createElement(__ds_scope.StatusPill, {
    status: status,
    size: "sm",
    showLabel: false
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), comments ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 3,
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "message-square",
    size: 12
  }), comments) : null, attachments ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 3,
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "paperclip",
    size: 12
  }), attachments) : null, due ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, due) : null, assignee ? /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: assignee,
    size: "xs"
  }) : null));
}
Object.assign(__ds_scope, { TaskCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/TaskCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/AppShell.jsx
try { (() => {
const {
  Icon,
  IconButton,
  Avatar,
  Kbd,
  Badge,
  Button,
  Tooltip
} = window.ForgeDesignSystem_8868ce;
const mono = {
  fontFamily: 'var(--font-mono)',
  fontSize: 'var(--text-2xs)',
  letterSpacing: 'var(--tracking-caps)',
  textTransform: 'uppercase',
  color: 'var(--text-tertiary)'
};

/* ── workspace switcher: a project is a workspace, not a sidebar item ── */
function WorkspaceButton({
  open,
  onToggle
}) {
  const ws = window.WORKSPACES[0];
  return /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      width: '100%',
      padding: '11px 12px',
      background: open ? 'var(--surface-card)' : 'transparent',
      border: 0,
      borderBottom: '1px solid var(--border-subtle)',
      cursor: 'pointer',
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 26,
      borderRadius: 7,
      background: ws.color,
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      lineHeight: 1.25,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      fontWeight: 600,
      color: 'var(--text-primary)'
    }
  }, ws.name), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      fontSize: 11,
      color: 'var(--text-tertiary)'
    }
  }, ws.open, " open")), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 13,
    style: {
      marginLeft: 'auto',
      color: 'var(--text-tertiary)'
    }
  }));
}
function WorkspaceMenu({
  onClose
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 8,
      left: 8,
      width: 266,
      zIndex: 6,
      padding: 5,
      display: 'flex',
      flexDirection: 'column',
      gap: 1,
      background: 'var(--surface-overlay-bg)',
      border: '1px solid var(--border-strong)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-lg)',
      animation: 'forge-rise var(--duration-fast) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...mono,
      padding: '8px 9px 5px'
    }
  }, "Workspaces"), window.WORKSPACES.map(w => /*#__PURE__*/React.createElement("button", {
    key: w.name,
    onClick: onClose,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      padding: '7px 9px',
      border: 0,
      background: w.on ? 'var(--surface-raised)' : 'transparent',
      borderRadius: 'var(--radius-md)',
      font: 'var(--type-ui)',
      fontWeight: w.on ? 500 : 400,
      color: w.on ? 'var(--text-primary)' : 'var(--text-secondary)',
      cursor: 'pointer',
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 17,
      height: 17,
      borderRadius: 4,
      background: w.color,
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, w.name), w.on ? /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 13,
    style: {
      color: 'var(--text-accent)'
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-tertiary)'
    }
  }, w.open))), /*#__PURE__*/React.createElement("hr", {
    style: {
      border: 0,
      borderTop: '1px solid var(--border-strong)',
      margin: '5px 3px',
      width: '100%'
    }
  }), ['Workspace settings', 'New workspace', 'All workspaces'].map(l => /*#__PURE__*/React.createElement("button", {
    key: l,
    onClick: onClose,
    style: {
      display: 'flex',
      padding: '7px 9px',
      border: 0,
      background: 'none',
      borderRadius: 'var(--radius-md)',
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: 'var(--text-secondary)',
      cursor: 'pointer',
      textAlign: 'left'
    }
  }, l)));
}

/* ── faceted filter rail — the rail's job, not navigation ── */
function MenuRow({
  item,
  checked,
  onToggle
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onToggle,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      width: '100%',
      padding: '5px 8px',
      border: 0,
      borderRadius: 'var(--radius-md)',
      cursor: 'pointer',
      textAlign: 'left',
      background: hover ? 'var(--surface-hover)' : 'transparent',
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: checked || hover ? 'var(--text-primary)' : 'var(--text-secondary)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'grid',
      placeItems: 'center',
      width: 12,
      height: 12,
      flex: 'none',
      borderRadius: 3,
      border: '1px solid ' + (checked ? 'var(--accent-solid)' : 'var(--border-strong)'),
      background: checked ? 'var(--accent-solid)' : 'transparent',
      color: 'var(--accent-on-solid)'
    }
  }, checked ? /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 8
  }) : null), item.dot ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 999,
      background: item.dot,
      flex: 'none'
    }
  }) : null, item.bars != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 1.5,
      height: 9,
      width: 11,
      flex: 'none'
    }
  }, [3, 6, 9].map((h, i) => /*#__PURE__*/React.createElement("i", {
    key: i,
    style: {
      width: 2.5,
      height: h,
      borderRadius: 1,
      background: i < item.bars ? item.color : 'var(--border-strong)'
    }
  }))) : null, item.agent ? /*#__PURE__*/React.createElement(Icon, {
    name: "sparkles",
    size: 11,
    style: {
      color: 'var(--text-accent)'
    }
  }) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, item.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-tertiary)'
    }
  }, item.count));
}

/* Every filter reads "label: value". The value opens a checkbox menu; one pick
   shows that value, several collapse to "N selected". */
function FilterRow({
  facet,
  picks,
  setPicks,
  open,
  onOpen
}) {
  const [rect, setRect] = React.useState(null);
  const [hover, setHover] = React.useState(false);
  const ref = React.useRef(null);
  const empty = !facet.items.length;
  const show = () => {
    if (empty) return;
    setRect(ref.current.getBoundingClientRect());
    onOpen(open ? null : facet.label);
  };
  React.useEffect(() => {
    if (!open) return;
    const away = e => {
      const t = e.target;
      const inMenu = t && t.closest && t.closest('[data-facet-menu]');
      if (ref.current && !ref.current.contains(t) && !inMenu) onOpen(null);
    };
    const esc = e => {
      if (e.key === 'Escape') onOpen(null);
    };
    document.addEventListener('mousedown', away);
    document.addEventListener('keydown', esc);
    return () => {
      document.removeEventListener('mousedown', away);
      document.removeEventListener('keydown', esc);
    };
  }, [open]);
  const toggle = label => setPicks(facet.label, picks.includes(label) ? picks.filter(x => x !== label) : [...picks, label]);
  const value = empty ? 'Any' : picks.length === 0 ? 'Any' : picks.length === 1 ? picks[0] : picks.length + ' selected';
  const one = picks.length === 1 ? facet.items.find(i => i.label === picks[0]) : null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("button", {
    ref: ref,
    type: "button",
    onClick: show,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      width: '100%',
      height: 28,
      padding: '0 8px',
      border: 0,
      borderRadius: 'var(--radius-md)',
      cursor: empty ? 'default' : 'pointer',
      textAlign: 'left',
      background: open ? 'var(--surface-active)' : hover && !empty ? 'var(--surface-hover)' : 'transparent',
      font: 'var(--type-ui)',
      fontWeight: 400,
      opacity: empty ? .5 : 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)',
      flex: 'none'
    }
  }, facet.label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      flex: 1,
      minWidth: 0,
      justifyContent: 'flex-end'
    }
  }, one && one.dot ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: 999,
      background: one.dot,
      flex: 'none'
    }
  }) : null, one && one.agent ? /*#__PURE__*/React.createElement(Icon, {
    name: "sparkles",
    size: 11,
    style: {
      color: 'var(--text-accent)'
    }
  }) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      color: picks.length ? 'var(--text-primary)' : 'var(--text-disabled)',
      fontWeight: picks.length ? 500 : 400
    }
  }, value), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 11,
    style: {
      color: 'var(--text-tertiary)',
      flex: 'none'
    }
  }))), open && rect ? /*#__PURE__*/React.createElement("div", {
    "data-facet-menu": true,
    style: {
      position: 'fixed',
      top: rect.bottom + 4,
      left: rect.left,
      width: Math.max(rect.width, 208),
      zIndex: 40,
      maxHeight: 320,
      overflowY: 'auto',
      padding: 5,
      display: 'flex',
      flexDirection: 'column',
      gap: 1,
      background: 'var(--surface-overlay-bg)',
      border: '1px solid var(--border-strong)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-lg)',
      animation: 'forge-rise var(--duration-fast) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      ...mono,
      fontSize: 9.5,
      padding: '6px 8px 4px'
    }
  }, facet.label, /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      textTransform: 'none',
      letterSpacing: '.06em',
      color: 'var(--border-strong)'
    }
  }, facet.src)), facet.items.map(it => /*#__PURE__*/React.createElement(MenuRow, {
    key: it.label,
    item: it,
    checked: picks.includes(it.label),
    onToggle: () => toggle(it.label)
  })), picks.length ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setPicks(facet.label, []),
    style: {
      marginTop: 3,
      padding: '6px 8px',
      border: 0,
      borderTop: '1px solid var(--border-strong)',
      background: 'none',
      cursor: 'pointer',
      textAlign: 'left',
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, "Clear ", facet.label.toLowerCase()) : null) : null);
}
function Sidebar() {
  const [menu, setMenu] = React.useState(false);
  const [picks, setPicksMap] = React.useState({
    Status: ['Ready', 'Running'],
    Priority: [],
    Assignee: [],
    Labels: [],
    Due: []
  });
  const [openFacet, setOpenFacet] = React.useState(null);
  const setPicks = (facet, next) => setPicksMap(p => ({
    ...p,
    [facet]: next
  }));
  const total = Object.values(picks).reduce((n, v) => n + v.length, 0);
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      minHeight: 0,
      background: 'var(--surface-page)',
      borderRight: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(WorkspaceButton, {
    open: menu,
    onToggle: () => setMenu(!menu)
  }), menu ? /*#__PURE__*/React.createElement(WorkspaceMenu, {
    onClose: () => setMenu(false)
  }) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '6px 8px',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#docs",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '6px 8px',
      borderRadius: 'var(--radius-md)',
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: 'var(--text-secondary)',
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "file-text",
    size: 13
  }), "Docs", /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-tertiary)'
    }
  }, "12"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 8px',
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      overflowY: 'auto',
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      padding: '6px 9px',
      marginBottom: 10,
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 13
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, "Search tasks"), /*#__PURE__*/React.createElement(Kbd, null, "/")), /*#__PURE__*/React.createElement("div", {
    style: {
      ...mono,
      fontSize: 9.5,
      padding: '0 8px 6px'
    }
  }, "Filters"), window.FACETS.map(fc => /*#__PURE__*/React.createElement(FilterRow, {
    key: fc.label,
    facet: fc,
    picks: picks[fc.label] || [],
    setPicks: setPicks,
    open: openFacet === fc.label,
    onOpen: setOpenFacet
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      paddingTop: 10,
      borderTop: '1px solid var(--border-subtle)',
      display: 'flex',
      gap: 8,
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setPicksMap({
      Status: [],
      Priority: [],
      Assignee: [],
      Labels: [],
      Due: []
    }),
    style: {
      border: 0,
      background: 'none',
      padding: 0,
      cursor: 'pointer',
      font: 'inherit',
      color: 'inherit'
    }
  }, "Clear all"), /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-accent)',
      fontWeight: 500
    }
  }, total))));
}

/* ── toolbar: one view, so the view selector names the saved filter set ── */
function Chip({
  children,
  onClick,
  accent
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '4px 9px',
      background: accent ? 'var(--accent-soft)' : 'var(--surface-card)',
      border: '1px solid ' + (accent ? 'var(--accent-soft-border)' : 'var(--border-subtle)'),
      borderRadius: 'var(--radius-md)',
      cursor: 'pointer',
      flex: 'none',
      whiteSpace: 'nowrap',
      font: 'var(--type-ui)',
      fontWeight: accent ? 500 : 400,
      color: accent ? 'var(--text-accent)' : 'var(--text-secondary)'
    }
  }, children);
}
function Toolbar({
  shown,
  total,
  onNew
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      padding: '12px 18px',
      borderBottom: '1px solid var(--border-subtle)',
      flexWrap: 'nowrap',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      padding: '4px 8px',
      borderRadius: 'var(--radius-md)',
      font: 'var(--type-ui)',
      color: 'var(--text-primary)',
      cursor: 'pointer',
      flex: 'none',
      whiteSpace: 'nowrap'
    }
  }, "Open work", /*#__PURE__*/React.createElement("i", {
    style: {
      width: 5,
      height: 5,
      borderRadius: 999,
      background: 'var(--accent-solid)'
    }
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 11,
    style: {
      color: 'var(--text-tertiary)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 1,
      height: 18,
      background: 'var(--border-subtle)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)',
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-secondary)',
      fontWeight: 500
    }
  }, shown), " of ", total, " tasks"), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Chip, null, "Sort ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-primary)',
      fontWeight: 500
    }
  }, "Suggested")), /*#__PURE__*/React.createElement(Chip, null, "Group ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-primary)',
      fontWeight: 500
    }
  }, "Status")), /*#__PURE__*/React.createElement(Chip, {
    accent: true
  }, "Save view"), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 1,
      height: 18,
      background: 'var(--border-subtle)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: 'var(--status-done)',
      boxShadow: '0 0 0 3px rgba(111,199,162,.14)'
    }
  }), "live"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    onClick: onNew,
    style: {
      flex: 'none',
      whiteSpace: 'nowrap'
    }
  }, "New task ", /*#__PURE__*/React.createElement(Kbd, {
    style: {
      background: 'rgba(255,255,255,.16)',
      borderColor: 'rgba(255,255,255,.28)',
      color: 'inherit'
    }
  }, "C")));
}

/* ── stats band: what the workspace is, and what it is costing ── */
function Meter({
  m
}) {
  const over = m.pct >= 100;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      minWidth: 124
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 7,
      ...mono,
      fontSize: 9.5,
      color: over ? 'var(--danger-fg)' : 'var(--text-tertiary)'
    }
  }, m.label, /*#__PURE__*/React.createElement("em", {
    style: {
      marginLeft: 'auto',
      fontStyle: 'normal',
      fontSize: 10.5,
      letterSpacing: 0,
      color: 'var(--text-secondary)'
    }
  }, m.pct, "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 5,
      borderRadius: 3,
      background: 'var(--border-subtle)',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: '0 auto 0 0',
      width: Math.min(m.pct, 100) + '%',
      borderRadius: 3,
      background: over ? 'var(--warning-solid)' : 'var(--accent-solid)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10.5,
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-tertiary)'
    }
  }, m.budget, " \xB7 ", m.reset));
}
function StatsBand() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '10px 18px',
      background: 'var(--surface-page)',
      borderBottom: '1px solid var(--border-subtle)',
      flexWrap: 'nowrap',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 9,
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)',
      flex: 'none',
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-secondary)',
      background: 'var(--surface-raised)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 4,
      padding: '1px 7px'
    }
  }, "v2.14.0"), /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-primary)',
      fontWeight: 600
    }
  }, "28"), " tasks", /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-primary)',
      fontWeight: 600
    }
  }, "17"), " open", /*#__PURE__*/React.createElement("span", null, "\xB7"), "11 closed"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      flexWrap: 'nowrap'
    }
  }, window.METERS.map(m => /*#__PURE__*/React.createElement(Meter, {
    key: m.label,
    m: m
  })), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 11,
    style: {
      color: 'var(--text-tertiary)'
    }
  })));
}

/* ── activity dock: global, spans the full window under the sidebar ── */
function DockRow({
  r,
  onOpen
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onOpen,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '6px 16px',
      cursor: 'pointer',
      background: hover ? 'var(--surface-hover)' : 'transparent'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 12,
      height: 12,
      borderRadius: 3,
      background: r.ws.color,
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-tertiary)',
      width: 62
    }
  }, r.id), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: r.queued ? 'var(--text-tertiary)' : 'var(--text-primary)',
      flex: 1,
      minWidth: 0,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, r.title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-tertiary)',
      background: 'var(--surface-raised)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 4,
      padding: '1px 7px'
    }
  }, r.model), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 132,
      display: 'flex',
      alignItems: 'center',
      gap: 7
    }
  }, r.queued ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-tertiary)'
    }
  }, "next up") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 4,
      borderRadius: 2,
      background: 'var(--border-subtle)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: r.indeterminate ? {
      display: 'block',
      height: '100%',
      width: '100%',
      background: 'linear-gradient(90deg,transparent,var(--accent-solid),transparent)',
      backgroundSize: '200% 100%',
      animation: 'forge-scan 1.4s linear infinite'
    } : {
      display: 'block',
      height: '100%',
      width: r.step / r.of * 100 + '%',
      background: 'var(--accent-solid)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-tertiary)'
    }
  }, r.indeterminate ? 'planning' : r.step + '/' + r.of))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-tertiary)',
      width: 48,
      textAlign: 'right'
    }
  }, r.elapsed || ''), /*#__PURE__*/React.createElement(IconButton, {
    icon: r.queued ? 'x' : 'pause',
    size: "sm",
    label: r.queued ? 'Remove from queue' : 'Pause run'
  }));
}
function ActivityDock({
  open,
  onToggle,
  onOpen
}) {
  const active = window.RUNS.filter(r => !r.queued);
  const queued = window.RUNS.filter(r => r.queued);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 'none',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-page)',
      borderTop: '1px solid var(--border-strong)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '7px 16px',
      border: 0,
      background: 'none',
      cursor: 'pointer',
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: 'var(--text-secondary)',
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 12,
    style: {
      color: 'var(--text-tertiary)',
      transform: open ? 'none' : 'rotate(180deg)'
    }
  }), /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-primary)',
      fontWeight: 600
    }
  }, "Activity"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-tertiary)'
    }
  }, active.length, " running \xB7 ", queued.length, " queued"), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: 'var(--accent-solid)',
      animation: 'forge-pulse var(--duration-pulse) infinite'
    }
  }), "all workspaces")), open ? /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: 190,
      overflowY: 'auto',
      paddingBottom: 4
    }
  }, active.map(r => /*#__PURE__*/React.createElement(DockRow, {
    key: r.id,
    r: r,
    onOpen: onOpen
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      ...mono,
      fontSize: 9.5,
      padding: '8px 16px 4px'
    }
  }, "Queued"), queued.map(r => /*#__PURE__*/React.createElement(DockRow, {
    key: r.id,
    r: r,
    onOpen: onOpen
  }))) : null);
}
Object.assign(window, {
  Sidebar,
  Toolbar,
  StatsBand,
  ActivityDock,
  Chip
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/BoardScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  Icon,
  IconButton,
  TaskCard
} = window.ForgeDesignSystem_8868ce;

/* Board is the only view — a switcher with one option is chrome, so the toolbar
   names the saved filter set instead. */
function BoardColumn({
  column,
  tasks,
  onOpen,
  selected
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 268,
      flex: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      padding: '0 2px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: 999,
      background: 'var(--status-' + column.key + ')'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-primary)'
    }
  }, column.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-tertiary)'
    }
  }, tasks.length), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "plus",
    size: "sm",
    label: 'Add to ' + column.label
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, tasks.map(t => /*#__PURE__*/React.createElement(TaskCard, _extends({
    key: t.id
  }, t, {
    selected: selected === t.id,
    onClick: () => onOpen(t)
  }))), tasks.length ? null : /*#__PURE__*/React.createElement("div", {
    style: {
      height: 56,
      border: '1px dashed var(--border-subtle)',
      borderRadius: 'var(--radius-lg)'
    }
  })));
}
function BoardScreen({
  onOpen,
  selected
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto',
      padding: 16,
      background: 'var(--surface-card)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start'
    }
  }, window.COLUMNS.map(c => /*#__PURE__*/React.createElement(BoardColumn, {
    key: c.key,
    column: c,
    selected: selected,
    tasks: window.TASKS.filter(t => t.status === c.key),
    onOpen: onOpen
  }))));
}
Object.assign(window, {
  BoardScreen,
  BoardColumn
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/BoardScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/TaskView.jsx
try { (() => {
const {
  Icon,
  IconButton,
  Button,
  Badge,
  Tag,
  Avatar,
  StatusPill,
  AgentRunIndicator,
  ExecutionLog,
  ApprovalBanner,
  ProgressBar,
  Textarea,
  Input,
  Card,
  Kbd
} = window.ForgeDesignSystem_8868ce;

/* Pipeline order. A tab unlocks once the task has reached its stage; the tab that
   matches the current status is highlighted and selected on open. */
const TABS = [{
  value: 'description',
  label: 'Description',
  stage: 0
}, {
  value: 'questions',
  label: 'Questions',
  stage: 1
}, {
  value: 'design',
  label: 'Design',
  stage: 2
}, {
  value: 'execution',
  label: 'Execution',
  stage: 3
}, {
  value: 'test',
  label: 'Test',
  stage: 4
}, {
  value: 'review',
  label: 'Review',
  stage: 5
}];
const REACHED = {
  'open-questions': 1,
  design: 2,
  ready: 2,
  running: 3,
  testing: 4,
  reviewing: 5,
  paused: 3,
  failed: 4,
  canceled: 3,
  done: 5
};
const FOCUS = {
  'open-questions': 'questions',
  design: 'design',
  ready: 'description',
  running: 'execution',
  testing: 'test',
  reviewing: 'review',
  paused: 'execution',
  failed: 'execution',
  canceled: 'description',
  done: 'review'
};
function Prop({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      minHeight: 26,
      padding: '0 0',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 92,
      flex: 'none',
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      flexWrap: 'wrap',
      minWidth: 0
    }
  }, children));
}
function SizePill({
  size
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-secondary)',
      background: 'var(--surface-raised)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 4,
      padding: '1px 7px'
    }
  }, size || 'M');
}
function TabBar({
  value,
  onChange,
  reached,
  focus
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 2,
      borderBottom: '1px solid var(--border-default)',
      padding: '0 20px'
    }
  }, TABS.map(t => {
    const enabled = t.stage <= reached;
    const on = t.value === value;
    const hot = t.value === focus;
    return /*#__PURE__*/React.createElement("button", {
      key: t.value,
      type: "button",
      disabled: !enabled,
      onClick: () => enabled && onChange(t.value),
      title: enabled ? undefined : 'Not reached yet',
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        height: 34,
        padding: '0 10px',
        border: 0,
        background: 'none',
        marginBottom: -1,
        cursor: enabled ? 'pointer' : 'not-allowed',
        borderBottom: '2px solid ' + (on ? 'var(--accent-solid)' : 'transparent'),
        font: 'var(--type-ui)',
        opacity: enabled ? 1 : .38,
        color: on ? 'var(--text-primary)' : hot ? 'var(--text-accent)' : 'var(--text-tertiary)',
        transition: 'var(--transition-control)'
      }
    }, t.label, hot && !on ? /*#__PURE__*/React.createElement("i", {
      style: {
        width: 5,
        height: 5,
        borderRadius: 999,
        background: 'var(--accent-solid)'
      }
    }) : null);
  }));
}
function Body({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 20px 32px',
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      maxWidth: 860
    }
  }, children);
}
function SectionLabel({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-overline)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase',
      color: 'var(--text-tertiary)'
    }
  }, children);
}
function DescriptionTab({
  task
}) {
  return /*#__PURE__*/React.createElement(Body, null, /*#__PURE__*/React.createElement(SectionLabel, null, "Objective"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      color: 'var(--text-body)',
      margin: 0
    }
  }, "Port every webhook handler from the v1 signature scheme to v2, keep a shim behind the ", /*#__PURE__*/React.createElement("code", null, "billing_v2"), " flag, and generate coverage for each event type. Do not touch the payout handlers."), /*#__PURE__*/React.createElement(SectionLabel, null, "Instructions to the agent"), /*#__PURE__*/React.createElement(Card, {
    padding: "sm",
    style: {
      background: 'var(--surface-raised)'
    }
  }, /*#__PURE__*/React.createElement("ol", {
    style: {
      margin: 0,
      paddingLeft: 18,
      font: 'var(--type-body)',
      color: 'var(--text-body)',
      display: 'flex',
      flexDirection: 'column',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("li", null, "Read ", /*#__PURE__*/React.createElement("code", null, "docs/stripe-v2.md"), " and the current handler map."), /*#__PURE__*/React.createElement("li", null, "Port handlers one at a time; each lands with its own test."), /*#__PURE__*/React.createElement("li", null, "Keep the v1 shim until support signs off on the runbook."), /*#__PURE__*/React.createElement("li", null, "Stop and ask before touching anything under ", /*#__PURE__*/React.createElement("code", null, "payouts/"), "."))), /*#__PURE__*/React.createElement(SectionLabel, null, "Context"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, [['stripe-v2-spec.pdf', '2.4 MB'], ['ledger-schema.sql', '18 KB'], ['docs/stripe-v2.md', 'workspace']].map(([n, m]) => /*#__PURE__*/React.createElement("div", {
    key: n,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: 'var(--text-secondary)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "paperclip",
    size: 13,
    style: {
      color: 'var(--text-tertiary)'
    }
  }), n, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-tertiary)'
    }
  }, m)))));
}
function QuestionsTab() {
  return /*#__PURE__*/React.createElement(Body, null, /*#__PURE__*/React.createElement(ApprovalBanner, {
    tone: "warning",
    title: "Atlas stopped to ask, rather than guess",
    description: "Two answers are blocking the design stage.",
    actions: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary"
    }, "Send answers")
  }), [['Should the v1 shim stay behind a flag, or be removed in the same change?', 'Removing it now means support loses the fallback mid-migration; keeping it means dead code until Q4.'], ['Do replayed events need to preserve their original timestamps?', 'The ledger indexes on received_at, so replays would land out of order unless we backdate them.']].map(([q, why], i) => /*#__PURE__*/React.createElement(Card, {
    key: i,
    padding: "sm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 9
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-help",
    size: 15,
    style: {
      color: 'var(--status-open-questions)',
      marginTop: 2,
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-h3)',
      fontSize: 'var(--text-md)',
      color: 'var(--text-primary)'
    }
  }, q), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-body)',
      color: 'var(--text-secondary)'
    }
  }, why), /*#__PURE__*/React.createElement(Textarea, {
    rows: 2,
    placeholder: "Answer\u2026"
  }))))));
}
function DesignTab() {
  return /*#__PURE__*/React.createElement(Body, null, /*#__PURE__*/React.createElement(SectionLabel, null, "Proposed approach"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      color: 'var(--text-body)',
      margin: 0
    }
  }, "Route every event through one verifier that accepts both signature schemes, then delete the v1 branch once the shim flag is off. Handlers stay pure; only the transport changes."), /*#__PURE__*/React.createElement(SectionLabel, null, "Options considered"), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden'
    }
  }, [['Dual verifier behind one entry point', 'Chosen', 'One code path, one flag to remove later.', true], ['Parallel v2 endpoint', 'Rejected', 'Doubles the surface support has to reason about.', false], ['Big-bang cutover', 'Rejected', 'No rollback if a provider lags on the new scheme.', false]].map(([n, verdict, why, on], i) => /*#__PURE__*/React.createElement("div", {
    key: n,
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 10,
      padding: '10px 12px',
      borderTop: i ? '1px solid var(--border-subtle)' : 0,
      background: on ? 'var(--accent-soft)' : 'transparent'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: on ? 'circle-check' : 'circle-slash',
    size: 14,
    style: {
      color: on ? 'var(--status-done)' : 'var(--text-disabled)',
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-primary)'
    }
  }, n), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-secondary)',
      marginTop: 2
    }
  }, why)), /*#__PURE__*/React.createElement(Badge, {
    size: "sm",
    tone: on ? 'accent' : 'neutral'
  }, verdict)))), /*#__PURE__*/React.createElement(SectionLabel, null, "Decision"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      font: 'var(--type-body)',
      color: 'var(--text-secondary)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Mara Vidal",
    size: "xs"
  }), "Approved by Mara Vidal \xB7 Aug 5, 11:20 \xB7 recorded as ", /*#__PURE__*/React.createElement("code", null, "decisions/0007-webhook-verifier.md")));
}
function ExecutionTab({
  task,
  approved,
  onApprove
}) {
  return /*#__PURE__*/React.createElement(Body, null, approved ? /*#__PURE__*/React.createElement(ApprovalBanner, {
    tone: "warning",
    title: "Approved by you \xB7 14:04",
    description: "Atlas resumed and is deploying to staging.",
    actions: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      icon: "undo-2"
    }, "Undo")
  }) : /*#__PURE__*/React.createElement(ApprovalBanner, {
    title: "Approval needed to deploy to staging",
    description: "Milestone 2 of 4 \xB7 12 files changed \xB7 31/31 tests passing",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      size: "sm"
    }, "Request changes"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      icon: "check",
      onClick: onApprove
    }, "Approve"))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 220px',
      gap: 16,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(ExecutionLog, {
    live: true,
    entries: window.LOG,
    height: 260
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(ProgressBar, {
    value: task.progress || 62,
    label: "Execution"
  }), [['read spec', true], ['port handlers', true], ['generate tests', true], ['deploy staging', false], ['verify + close', false]].map(([s, done]) => /*#__PURE__*/React.createElement("div", {
    key: s,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: done ? 'var(--text-tertiary)' : 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: done ? 'circle-check' : 'circle-dashed',
    size: 13,
    style: {
      color: done ? 'var(--status-done)' : 'var(--text-disabled)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      textDecoration: done ? 'line-through' : 'none'
    }
  }, s))))), /*#__PURE__*/React.createElement(SectionLabel, null, "Artifacts"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, [['webhooks-v2.diff', '12 files · +684 −211', 'git-compare'], ['coverage-report.html', '31 tests · 94% lines', 'file-check-2'], ['migration-runbook.md', 'draft · 4 steps', 'file-text']].map(([n, m, ic]) => /*#__PURE__*/React.createElement(Card, {
    key: n,
    padding: "sm",
    interactive: true,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 15,
    style: {
      color: 'var(--text-tertiary)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-primary)'
    }
  }, n), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, m)), /*#__PURE__*/React.createElement(Badge, {
    tone: "accent",
    size: "sm",
    icon: "sparkles"
  }, "Atlas")))));
}
function TestTab() {
  const rows = [['verifies v2 signatures', 'regression', 'pass', '0.14s'], ['rejects tampered payloads', 'regression', 'pass', '0.09s'], ['replays idempotently', 'task', 'pass', '1.20s'], ['falls back to v1 behind the flag', 'task', 'pass', '0.31s'], ['handles clock skew over 5 minutes', 'task', 'fail', '0.44s']];
  return /*#__PURE__*/React.createElement(Body, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "success",
    icon: "circle-check"
  }, "30 passing"), /*#__PURE__*/React.createElement(Badge, {
    tone: "danger",
    icon: "circle-x"
  }, "1 failing"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-tertiary)'
    }
  }, "2.18s \xB7 pnpm test billing"), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    icon: "refresh-cw"
  }, "Re-run")), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 92px 72px 64px',
      gap: 10,
      padding: '7px 12px',
      background: 'var(--surface-raised)',
      font: 'var(--type-overline)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "Test"), /*#__PURE__*/React.createElement("span", null, "Kind"), /*#__PURE__*/React.createElement("span", null, "Result"), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: 'right'
    }
  }, "Time")), rows.map(([n, k, res, t], i) => /*#__PURE__*/React.createElement("div", {
    key: n,
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 92px 72px 64px',
      gap: 10,
      alignItems: 'center',
      padding: '8px 12px',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: 'var(--text-primary)'
    }
  }, n), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-tertiary)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      font: 'var(--type-caption)',
      color: res === 'pass' ? 'var(--success-fg)' : 'var(--danger-fg)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: res === 'pass' ? 'circle-check' : 'circle-x',
    size: 12
  }), res), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-tertiary)',
      textAlign: 'right'
    }
  }, t)))), /*#__PURE__*/React.createElement(Card, {
    padding: "sm",
    style: {
      borderColor: 'var(--danger-bg)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-primary)'
    }
  }, "handles clock skew over 5 minutes"), /*#__PURE__*/React.createElement("pre", {
    style: {
      margin: '8px 0 0',
      font: 'var(--type-mono)',
      color: 'var(--text-secondary)',
      whiteSpace: 'pre-wrap'
    }
  }, "expected: accepted with tolerance 300s", '\n', "received: SignatureExpired at t+301s")));
}
function ReviewTab({
  approved,
  onApprove
}) {
  return /*#__PURE__*/React.createElement(Body, null, /*#__PURE__*/React.createElement(Card, {
    padding: "md"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Atlas",
    kind: "agent",
    size: "sm"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-primary)'
    }
  }, "Agent review"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, "read the description, the cumulative diff and the test output")), /*#__PURE__*/React.createElement(Badge, {
    tone: "warning",
    icon: "circle-alert"
  }, "1 concern")), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body)',
      color: 'var(--text-body)',
      margin: '12px 0 0'
    }
  }, "The port is complete and behaviour-preserving for every event type in the spec. One concern: the clock-skew tolerance is hard-coded at 300s in two places, and the failing test suggests the second one was missed. Recommend extracting it before sign-off.")), /*#__PURE__*/React.createElement(SectionLabel, null, "Changes"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "12 files"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--success-fg)',
      fontFamily: 'var(--font-mono)'
    }
  }, "+684"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--danger-fg)',
      fontFamily: 'var(--font-mono)'
    }
  }, "\u2212211"), /*#__PURE__*/React.createElement("span", null, "across billing/, tests/, docs/")), /*#__PURE__*/React.createElement(SectionLabel, null, "Comments"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 13
    }
  }, [['Mara Vidal', 'user', '2h', 'Keep the v1 shim until support finishes the runbook.'], ['Atlas', 'agent', '46m', 'Shim retained behind billing_v2. Removal is queued as FRG-226.'], ['Dev Okafor', 'user', '12m', 'Nice. I will take the rate-limit follow-up.']].map(([n, k, t, msg]) => /*#__PURE__*/React.createElement("div", {
    key: n + t,
    style: {
      display: 'flex',
      gap: 9
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: n,
    kind: k,
    size: "sm"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 7,
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-primary)'
    }
  }, n), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, t, " ago")), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-body)',
      color: 'var(--text-body)',
      marginTop: 2
    }
  }, msg)))), /*#__PURE__*/React.createElement(Textarea, {
    rows: 2,
    placeholder: "Comment or give the agent feedback\u2026"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "md",
    icon: "undo-2"
  }, "Request changes"), /*#__PURE__*/React.createElement(Button, {
    size: "md",
    variant: "primary",
    icon: "check",
    onClick: onApprove,
    disabled: approved
  }, approved ? 'Approved' : 'Approve and close')));
}

/* The task opens as a full view in the main pane — properties first, then the
   pipeline as tabs. Stages the task has not reached are disabled. */
function TaskView({
  task,
  onBack,
  approved,
  onApprove
}) {
  const reached = REACHED[task.status] != null ? REACHED[task.status] : 0;
  const focus = FOCUS[task.status] || 'description';
  const [tab, setTab] = React.useState(focus);
  React.useEffect(() => {
    setTab(FOCUS[task.status] || 'description');
  }, [task.id]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      minHeight: 0,
      flex: 1,
      background: 'var(--surface-card)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '10px 18px',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "arrow-left",
    size: "sm",
    label: "Back to board",
    onClick: onBack
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-tertiary)'
    }
  }, task.id), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-primary)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, task.title), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Kbd, null, "Esc"), /*#__PURE__*/React.createElement(IconButton, {
    icon: "link",
    size: "sm",
    label: "Copy link"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "ellipsis",
    size: "sm",
    label: "More"
  }), task.agent ? /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    icon: "pause"
  }, "Pause agent") : null), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '18px 20px 16px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--type-h1)',
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text-primary)',
      margin: '0 0 14px',
      maxWidth: 780
    }
  }, task.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '0 40px',
      maxWidth: 860
    }
  }, /*#__PURE__*/React.createElement(Prop, {
    label: "Status"
  }, /*#__PURE__*/React.createElement(StatusPill, {
    status: task.status,
    size: "sm"
  })), /*#__PURE__*/React.createElement(Prop, {
    label: "Agent"
  }, task.agent ? /*#__PURE__*/React.createElement(AgentRunIndicator, {
    agent: task.agent,
    state: task.status === 'running' ? 'running' : 'idle',
    compact: true
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: 'var(--text-tertiary)'
    }
  }, "unassigned")), /*#__PURE__*/React.createElement(Prop, {
    label: "Priority"
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: task.priority === 'urgent' ? 'danger' : task.priority === 'high' ? 'warning' : 'neutral',
    size: "sm",
    icon: task.priority === 'low' ? 'signal-low' : task.priority === 'medium' ? 'signal-medium' : 'signal-high'
  }, task.priority)), /*#__PURE__*/React.createElement(Prop, {
    label: "Model"
  }, /*#__PURE__*/React.createElement(Badge, {
    size: "sm"
  }, "claude-sonnet-4.5")), /*#__PURE__*/React.createElement(Prop, {
    label: "Size"
  }, /*#__PURE__*/React.createElement(SizePill, {
    size: task.size
  })), /*#__PURE__*/React.createElement(Prop, {
    label: "Reviewer"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: task.assignee || 'Mara Vidal',
    size: "xs"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: 'var(--text-body)'
    }
  }, task.assignee || 'Mara Vidal')), /*#__PURE__*/React.createElement(Prop, {
    label: "Labels"
  }, (task.labels || []).map(l => /*#__PURE__*/React.createElement(Tag, {
    key: l.name,
    color: l.color
  }, l.name))), /*#__PURE__*/React.createElement(Prop, {
    label: "Due"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: 'var(--text-body)'
    }
  }, task.due || '—')), /*#__PURE__*/React.createElement(Prop, {
    label: "Branch"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-secondary)'
    }
  }, "forge/", task.id.toLowerCase())), /*#__PURE__*/React.createElement(Prop, {
    label: "Updated"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: 'var(--text-body)'
    }
  }, "4 min ago")))), /*#__PURE__*/React.createElement(TabBar, {
    value: tab,
    onChange: setTab,
    reached: reached,
    focus: focus
  }), tab === 'description' ? /*#__PURE__*/React.createElement(DescriptionTab, {
    task: task
  }) : null, tab === 'questions' ? /*#__PURE__*/React.createElement(QuestionsTab, null) : null, tab === 'design' ? /*#__PURE__*/React.createElement(DesignTab, null) : null, tab === 'execution' ? /*#__PURE__*/React.createElement(ExecutionTab, {
    task: task,
    approved: approved,
    onApprove: onApprove
  }) : null, tab === 'test' ? /*#__PURE__*/React.createElement(TestTab, null) : null, tab === 'review' ? /*#__PURE__*/React.createElement(ReviewTab, {
    approved: approved,
    onApprove: onApprove
  }) : null));
}
Object.assign(window, {
  TaskView
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/TaskView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/data.js
try { (() => {
const LABELS = {
  infra: {
    name: 'infra',
    color: 'var(--blue-500)'
  },
  backend: {
    name: 'backend',
    color: 'var(--green-500)'
  },
  design: {
    name: 'design',
    color: 'var(--violet-500)'
  },
  docs: {
    name: 'docs',
    color: 'var(--gray-500)'
  },
  billing: {
    name: 'billing',
    color: 'var(--amber-500)'
  }
};
const WORKSPACES = [{
  name: 'Billing v2',
  color: 'var(--ember-500)',
  open: 17,
  on: true
}, {
  name: 'Forge Web',
  color: 'var(--violet-500)',
  open: 9
}, {
  name: 'Platform infra',
  color: 'var(--blue-500)',
  open: 24
}, {
  name: 'Support ops',
  color: 'var(--green-500)',
  open: 4
}];
const TASKS = [{
  id: 'FRG-214',
  size: 'L',
  title: 'Migrate billing webhooks to the v2 API',
  status: 'running',
  priority: 'high',
  agent: 'Atlas',
  progress: 62,
  labels: [LABELS.infra, LABELS.backend],
  comments: 3,
  attachments: 2,
  due: 'Aug 8'
}, {
  id: 'FRG-219',
  size: 'M',
  title: 'Reconcile failed Stripe events from July',
  status: 'running',
  priority: 'urgent',
  agent: 'Ledger',
  progress: 24,
  labels: [LABELS.billing],
  comments: 1,
  due: 'Aug 7'
}, {
  id: 'FRG-230',
  size: 'S',
  title: 'Verify idempotent retries against the sandbox',
  status: 'testing',
  priority: 'high',
  agent: 'Atlas',
  progress: 88,
  labels: [LABELS.backend],
  comments: 2
}, {
  id: 'FRG-208',
  size: 'M',
  title: 'Draft the migration runbook for support',
  status: 'reviewing',
  priority: 'medium',
  agent: 'Scribe',
  progress: 100,
  labels: [LABELS.docs],
  comments: 8
}, {
  id: 'FRG-211',
  size: 'S',
  title: 'Invoice PDF template refresh',
  status: 'reviewing',
  priority: 'low',
  assignee: 'Mara Vidal',
  labels: [LABELS.design],
  comments: 2,
  attachments: 4
}, {
  id: 'FRG-221',
  size: 'L',
  title: 'Backfill customer events into the ledger',
  status: 'ready',
  priority: 'high',
  agent: 'Ledger',
  labels: [LABELS.backend],
  due: 'Aug 11'
}, {
  id: 'FRG-223',
  size: 'S',
  title: 'Rate-limit the webhook replay endpoint',
  status: 'ready',
  priority: 'medium',
  assignee: 'Dev Okafor',
  labels: [LABELS.infra]
}, {
  id: 'FRG-226',
  size: 'XL',
  title: 'Retire the legacy /charges endpoint',
  status: 'open-questions',
  priority: 'low',
  labels: [LABELS.infra, LABELS.docs],
  comments: 6
}, {
  id: 'FRG-228',
  size: 'XS',
  title: 'Dunning email copy pass',
  status: 'open-questions',
  priority: 'medium',
  labels: [LABELS.docs],
  comments: 2
}, {
  id: 'FRG-232',
  size: 'M',
  title: 'Failure-state screens for the replay flow',
  status: 'design',
  priority: 'medium',
  assignee: 'Mara Vidal',
  labels: [LABELS.design],
  attachments: 3
}, {
  id: 'FRG-217',
  size: 'S',
  title: 'Sync vendor sandbox credentials',
  status: 'paused',
  priority: 'urgent',
  agent: 'Ledger',
  labels: [LABELS.billing],
  comments: 4
}, {
  id: 'FRG-209',
  size: 'M',
  title: 'Bulk refund reconciliation job',
  status: 'failed',
  priority: 'high',
  agent: 'Ledger',
  progress: 41,
  labels: [LABELS.billing],
  comments: 3
}, {
  id: 'FRG-198',
  size: 'S',
  title: 'Legacy dunning webhook shim',
  status: 'canceled',
  priority: 'low',
  labels: [LABELS.infra]
}, {
  id: 'FRG-201',
  size: 'M',
  title: 'Idempotency keys on all write paths',
  status: 'done',
  priority: 'high',
  agent: 'Atlas',
  progress: 100,
  labels: [LABELS.backend],
  comments: 5
}, {
  id: 'FRG-204',
  size: 'L',
  title: 'Ledger schema migration 004',
  status: 'done',
  priority: 'medium',
  assignee: 'Dev Okafor',
  labels: [LABELS.infra]
}];
const COLUMNS = [{
  key: 'open-questions',
  label: 'Open questions'
}, {
  key: 'design',
  label: 'Design'
}, {
  key: 'ready',
  label: 'Ready'
}, {
  key: 'running',
  label: 'Running'
}, {
  key: 'testing',
  label: 'Testing'
}, {
  key: 'reviewing',
  label: 'Reviewing'
}, {
  key: 'done',
  label: 'Done'
}];

/* Left rail facets. Status comes from the pipeline; the rest from the workspace schema. */
const FACETS = [{
  label: 'Status',
  src: 'pipeline',
  open: true,
  items: [{
    label: 'Open questions',
    count: 2,
    dot: 'var(--status-open-questions)'
  }, {
    label: 'Design',
    count: 1,
    dot: 'var(--status-design)'
  }, {
    label: 'Ready',
    count: 5,
    dot: 'var(--status-ready)',
    on: true
  }, {
    label: 'Running',
    count: 2,
    dot: 'var(--status-running)',
    on: true
  }, {
    label: 'Testing',
    count: 1,
    dot: 'var(--status-testing)'
  }, {
    label: 'Reviewing',
    count: 2,
    dot: 'var(--status-reviewing)'
  }, {
    label: 'Paused',
    count: 1,
    dot: 'var(--status-paused)'
  }, {
    label: 'Failed',
    count: 1,
    dot: 'var(--status-failed)'
  }, {
    label: 'Done',
    count: 9,
    dot: 'var(--status-done)'
  }]
}, {
  label: 'Priority',
  src: 'core',
  open: true,
  items: [{
    label: 'Urgent',
    count: 2,
    bars: 3,
    color: 'var(--danger-fg)'
  }, {
    label: 'High',
    count: 4,
    bars: 2,
    color: 'var(--warning-fg)'
  }, {
    label: 'Medium',
    count: 6,
    bars: 1,
    color: 'var(--text-secondary)'
  }, {
    label: 'Low',
    count: 3,
    bars: 0,
    color: 'var(--text-disabled)'
  }]
}, {
  label: 'Assignee',
  src: 'core',
  open: true,
  items: [{
    label: 'Atlas',
    count: 3,
    agent: true
  }, {
    label: 'Ledger',
    count: 4,
    agent: true
  }, {
    label: 'Scribe',
    count: 1,
    agent: true
  }, {
    label: 'Mara Vidal',
    count: 2
  }, {
    label: 'Dev Okafor',
    count: 2
  }]
}, {
  label: 'Labels',
  src: 'core',
  open: false,
  items: []
}, {
  label: 'Due',
  src: 'core',
  open: false,
  items: []
}];

/* Token budget for this workspace — spend you can see, and stop. */
const METERS = [{
  label: '5-hour',
  pct: 46,
  budget: '0.9M / 2M tok',
  reset: 'ends 2h 14m'
}, {
  label: 'Weekly',
  pct: 71,
  budget: '7.1M / 10M tok',
  reset: 'ends Mon'
}, {
  label: 'Billing v2',
  pct: 118,
  budget: '2.4M / 2M tok',
  reset: 'ends Mon'
}];

/* The activity dock is global: every run in every workspace. */
const RUNS = [{
  ws: WORKSPACES[0],
  id: 'FRG-214',
  title: 'Migrate billing webhooks to the v2 API',
  model: 'claude-sonnet-4.5',
  step: 4,
  of: 6,
  elapsed: '2m 14s'
}, {
  ws: WORKSPACES[0],
  id: 'FRG-219',
  title: 'Reconcile failed Stripe events from July',
  model: 'claude-sonnet-4.5',
  step: 1,
  of: 5,
  elapsed: '0m 48s'
}, {
  ws: WORKSPACES[2],
  id: 'INF-88',
  title: 'Rotate staging certificates',
  model: 'claude-opus-4.1',
  indeterminate: true,
  elapsed: '0m 22s'
}, {
  ws: WORKSPACES[1],
  id: 'WEB-31',
  title: 'Changelog page metadata',
  model: 'gpt-5',
  queued: true
}, {
  ws: WORKSPACES[0],
  id: 'FRG-221',
  title: 'Backfill customer events into the ledger',
  model: 'claude-sonnet-4.5',
  queued: true
}];
const LOG = [{
  time: '14:02:09',
  level: 'info',
  message: 'run started · claude-sonnet-4.5 · tools: repo, shell, http'
}, {
  time: '14:02:11',
  level: 'tool',
  message: 'read_file("billing/webhooks.ts")'
}, {
  time: '14:02:14',
  level: 'tool',
  message: 'search_repo("stripe.constructEvent")  → 14 matches'
}, {
  time: '14:02:22',
  level: 'info',
  message: 'plan: port 12 handlers, keep v1 shim behind flag'
}, {
  time: '14:02:31',
  level: 'ok',
  message: '12 handlers ported · 31 tests generated'
}, {
  time: '14:02:38',
  level: 'tool',
  message: 'shell("pnpm test billing")'
}, {
  time: '14:02:44',
  level: 'warn',
  message: 'retry: rate limit on staging deploy (1/3)'
}, {
  time: '14:02:51',
  level: 'ok',
  message: '31/31 tests passing'
}, {
  time: '14:02:52',
  level: 'info',
  message: 'awaiting human approval — milestone 2 of 4'
}];
Object.assign(window, {
  LABELS,
  WORKSPACES,
  TASKS,
  COLUMNS,
  FACETS,
  METERS,
  RUNS,
  LOG
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/data.js", error: String((e && e.message) || e) }); }

// ui_kits/forge-web/ChangelogPage.jsx
try { (() => {
const {
  Badge,
  Icon,
  Card,
  Avatar
} = window.ForgeDesignSystem_8868ce;
const ENTRIES = [{
  v: '2.14.0',
  date: 'Aug 4, 2026',
  tag: ['accent', 'Agents'],
  title: 'Step-through runs',
  body: 'Pause an agent at every milestone instead of only at approval gates. Useful when you are still learning how a new agent behaves on your codebase.',
  bullets: ['New run mode in the task dialog', 'Resume from any completed step', 'Step plans render in the task rail']
}, {
  v: '2.13.2',
  date: 'Jul 28, 2026',
  tag: ['success', 'Fix'],
  title: 'Execution log retention',
  body: 'Logs no longer truncate at 5,000 lines on Team plans. Retention now follows the plan, not the buffer.',
  bullets: []
}, {
  v: '2.13.0',
  date: 'Jul 21, 2026',
  tag: ['info', 'Views'],
  title: 'Timeline view',
  body: 'Agent runs now render as durations on a shared timeline, with approval gates marked inline.',
  bullets: ['Drag to reschedule', 'Critical-path highlighting']
}];
function ChangelogPage() {
  return /*#__PURE__*/React.createElement(Section, {
    style: {
      paddingTop: 64,
      paddingBottom: 80
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--type-h1)',
      fontSize: 44,
      letterSpacing: 'var(--tracking-tighter)',
      color: 'var(--text-primary)',
      margin: '0 0 6px'
    }
  }, "Changelog"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      color: 'var(--text-secondary)',
      margin: '0 0 36px'
    }
  }, "What shipped, in plain language."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 28
    }
  }, ENTRIES.map(e => /*#__PURE__*/React.createElement("div", {
    key: e.v,
    style: {
      display: 'grid',
      gridTemplateColumns: '160px 1fr',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      paddingTop: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-primary)'
    }
  }, e.v), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, e.date), /*#__PURE__*/React.createElement(Badge, {
    tone: e.tag[0],
    size: "sm",
    style: {
      alignSelf: 'flex-start'
    }
  }, e.tag[1])), /*#__PURE__*/React.createElement(Card, {
    padding: "md"
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--type-h2)',
      fontSize: 21,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text-primary)',
      margin: '0 0 8px'
    }
  }, e.title), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      color: 'var(--text-body)',
      margin: 0,
      maxWidth: 'var(--prose-max)'
    }
  }, e.body), e.bullets.length ? /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: '12px 0 0',
      padding: 0,
      listStyle: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, e.bullets.map(b => /*#__PURE__*/React.createElement("li", {
    key: b,
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center',
      font: 'var(--type-body)',
      color: 'var(--text-secondary)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "corner-down-right",
    size: 13,
    style: {
      color: 'var(--text-disabled)'
    }
  }), b))) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      marginTop: 16,
      paddingTop: 12,
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Dev Okafor",
    size: "xs"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, "Dev Okafor \xB7 Engineering")))))));
}
Object.assign(window, {
  ChangelogPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-web/ChangelogPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-web/HomePage.jsx
try { (() => {
const {
  Button,
  Icon,
  Badge,
  Card,
  TaskCard,
  AgentRunIndicator,
  ExecutionLog,
  StatusPill,
  ApprovalBanner,
  Kbd
} = window.ForgeDesignSystem_8868ce;
function Section({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '0 28px',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--content-max)',
      margin: '0 auto'
    }
  }, children));
}
function Hero() {
  return /*#__PURE__*/React.createElement(Section, {
    style: {
      paddingTop: 84,
      paddingBottom: 56
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "accent",
    icon: "sparkles"
  }, "Agent runs are now generally available"), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--type-display)',
      fontSize: 62,
      letterSpacing: 'var(--tracking-tighter)',
      color: 'var(--text-primary)',
      margin: 0,
      maxWidth: 780
    }
  }, "Tasks that execute themselves"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      fontSize: 18,
      color: 'var(--text-secondary)',
      margin: 0,
      maxWidth: 560
    }
  }, "Forge is a project manager where work is delegated to AI agents, not just assigned to people. Define the objective, watch every action, approve what matters."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconEnd: "arrow-right"
  }, "Start free"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    icon: "play"
  }, "Watch a run")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center',
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, "Free for 3 agents \xB7 no card required")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 44,
      borderRadius: 'var(--radius-2xl)',
      border: '1px solid var(--border-default)',
      background: 'var(--surface-card)',
      boxShadow: 'var(--shadow-xl)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      height: 38,
      padding: '0 12px',
      borderBottom: '1px solid var(--border-subtle)',
      background: 'var(--surface-sunken)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 5
    }
  }, ['var(--gray-300)', 'var(--gray-300)', 'var(--gray-300)'].map((c, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: 9,
      height: 9,
      borderRadius: 999,
      background: c
    }
  }))), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)',
      marginLeft: 8
    }
  }, "Billing v2 \xB7 FRG-214"), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(AgentRunIndicator, {
    agent: "Atlas",
    step: "running tests",
    elapsed: "2m 14s",
    compact: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1.25fr',
      gap: 16,
      padding: 16,
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(TaskCard, {
    id: "FRG-214",
    title: "Migrate billing webhooks to the v2 API",
    status: "running",
    priority: "high",
    agent: "Atlas",
    progress: 62,
    labels: [{
      name: 'infra',
      color: 'var(--blue-500)'
    }],
    comments: 3
  }), /*#__PURE__*/React.createElement(TaskCard, {
    id: "FRG-208",
    title: "Draft the migration runbook",
    status: "reviewing",
    priority: "medium",
    agent: "Scribe",
    progress: 100,
    labels: [{
      name: 'docs',
      color: 'var(--gray-400)'
    }],
    comments: 8
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(ExecutionLog, {
    live: true,
    height: 150,
    entries: [{
      time: '14:02:11',
      level: 'tool',
      message: 'read_file("billing/webhooks.ts")'
    }, {
      time: '14:02:14',
      level: 'tool',
      message: 'search_repo("stripe.constructEvent")'
    }, {
      time: '14:02:31',
      level: 'ok',
      message: '12 handlers ported · 31 tests generated'
    }, {
      time: '14:02:44',
      level: 'warn',
      message: 'retry: rate limit on staging deploy (1/3)'
    }, {
      time: '14:02:51',
      level: 'ok',
      message: '31/31 tests passing'
    }]
  }), /*#__PURE__*/React.createElement(ApprovalBanner, {
    title: "Approve deploy to staging",
    description: "Milestone 2 of 4 \xB7 12 files changed",
    actions: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      icon: "check"
    }, "Approve")
  })))));
}
function LogoRow() {
  return /*#__PURE__*/React.createElement(Section, {
    style: {
      paddingBottom: 56
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 40,
      flexWrap: 'wrap',
      opacity: .5
    }
  }, ['Northwind', 'Cobalt', 'Harbor Labs', 'Vantage', 'Meridian', 'Rift'].map(n => /*#__PURE__*/React.createElement("span", {
    key: n,
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: 17,
      letterSpacing: '-.02em',
      color: 'var(--text-secondary)'
    }
  }, n))));
}
function Features() {
  const items = [['Delegate, do not dispatch', 'sparkles', 'Assign a task to an agent the same way you assign it to a teammate. It picks up the objective, the files and the constraints.'], ['Every action, on the record', 'terminal', 'A timestamped execution log for every run. Tool calls, retries, failures — nothing is summarised away.'], ['Approvals where they matter', 'shield-check', 'Gate a milestone and the agent pauses. Approve, request changes, or take the work back — inline, never in a modal.'], ['Status that updates itself', 'refresh-cw', 'Progress, state and due-date risk move as the agent works. Nobody drags a card to keep a board honest.'], ['Four views, one dataset', 'columns-3', 'List, board, calendar and timeline over the same tasks. Switch with a keystroke.'], ['Keyboard first', 'command', 'Every action has a shortcut. ⌘K reaches any project, task or agent in the workspace.']];
  return /*#__PURE__*/React.createElement(Section, {
    style: {
      paddingBottom: 72
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--type-h1)',
      fontSize: 34,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text-primary)',
      margin: '0 0 6px'
    }
  }, "An execution platform, not a task list"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      color: 'var(--text-secondary)',
      margin: '0 0 28px',
      maxWidth: 520
    }
  }, "Forge tracks work the way a build system tracks jobs \u2014 with state, logs and artifacts."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 14
    }
  }, items.map(([t, ic, d]) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    padding: "md"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 30,
      height: 30,
      borderRadius: 'var(--radius-md)',
      background: 'var(--accent-soft)',
      color: 'var(--text-accent)',
      border: '1px solid var(--accent-soft-border)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 15
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--type-h3)',
      color: 'var(--text-primary)',
      margin: '12px 0 4px'
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body)',
      color: 'var(--text-secondary)',
      margin: 0
    }
  }, d)))));
}
function Lifecycle() {
  const steps = [['ready', 'Define', 'Objective, instructions, files, deadline.'], ['running', 'Execute', 'The agent works, logging every tool call.'], ['testing', 'Verify', 'Tests run; failures come back with the log.'], ['reviewing', 'Review', 'You approve, comment, or take over.'], ['done', 'Ship', 'Artifacts attached, status closed automatically.']];
  return /*#__PURE__*/React.createElement(Section, {
    style: {
      paddingBottom: 72
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--gray-950)',
      borderRadius: 'var(--radius-2xl)',
      padding: '40px 36px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--type-h1)',
      fontSize: 32,
      letterSpacing: 'var(--tracking-tight)',
      color: '#fff',
      margin: '0 0 28px',
      maxWidth: 460
    }
  }, "The whole lifecycle, visible in one place"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(5,1fr)',
      gap: 18
    }
  }, steps.map(([s, t, d], i) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      paddingTop: 16,
      borderTop: '1px solid rgba(255,255,255,.14)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--ember-400)'
    }
  }, "0", i + 1), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-h3)',
      color: '#fff'
    }
  }, t), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body)',
      color: 'rgba(255,255,255,.62)'
    }
  }, d))))));
}
function CTA() {
  return /*#__PURE__*/React.createElement(Section, {
    style: {
      paddingBottom: 84
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 14,
      textAlign: 'center',
      padding: '48px 24px',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-2xl)',
      background: 'var(--surface-card)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--type-h1)',
      fontSize: 36,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text-primary)',
      margin: 0
    }
  }, "Put your backlog to work"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      color: 'var(--text-secondary)',
      margin: 0,
      maxWidth: 420
    }
  }, "Three agents free, forever. Connect a repo and run your first task in under five minutes."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconEnd: "arrow-right"
  }, "Start free"), /*#__PURE__*/React.createElement(Button, {
    size: "lg"
  }, "Talk to sales"))));
}
function HomePage() {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Hero, null), /*#__PURE__*/React.createElement(LogoRow, null), /*#__PURE__*/React.createElement(Features, null), /*#__PURE__*/React.createElement(Lifecycle, null), /*#__PURE__*/React.createElement(CTA, null));
}
Object.assign(window, {
  HomePage,
  Section
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-web/HomePage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-web/PricingPage.jsx
try { (() => {
const {
  Button,
  Icon,
  Badge,
  Card,
  Switch
} = window.ForgeDesignSystem_8868ce;
const PLANS = [{
  name: 'Free',
  price: '$0',
  unit: 'forever',
  desc: 'For solo work and evaluation.',
  cta: 'Start free',
  variant: 'secondary',
  features: ['3 agents', '200 runs / month', 'List and board views', 'Community support']
}, {
  name: 'Team',
  price: '$24',
  unit: 'per seat / month',
  desc: 'For teams running agents daily.',
  cta: 'Start 14-day trial',
  variant: 'primary',
  featured: true,
  features: ['Unlimited agents', '5,000 runs / month', 'All four views', 'Approval checkpoints', 'Execution log retention 90d', 'Priority support']
}, {
  name: 'Enterprise',
  price: 'Custom',
  unit: 'annual',
  desc: 'For regulated and large orgs.',
  cta: 'Talk to sales',
  variant: 'secondary',
  features: ['Bring your own models', 'SSO + SCIM', 'Audit export', 'Unlimited retention', 'Dedicated support']
}];
function PricingPage() {
  const [annual, setAnnual] = React.useState(true);
  return /*#__PURE__*/React.createElement(Section, {
    style: {
      paddingTop: 64,
      paddingBottom: 80
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 12,
      marginBottom: 34
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--type-h1)',
      fontSize: 44,
      letterSpacing: 'var(--tracking-tighter)',
      color: 'var(--text-primary)',
      margin: 0
    }
  }, "Priced per person, not per agent"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      color: 'var(--text-secondary)',
      margin: 0,
      maxWidth: 460
    }
  }, "Run as much work as you like. We charge for the humans supervising it."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    checked: annual,
    onChange: setAnnual,
    label: "Annual billing"
  }), /*#__PURE__*/React.createElement(Badge, {
    tone: "success",
    size: "sm"
  }, "2 months free"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 14,
      alignItems: 'start'
    }
  }, PLANS.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.name,
    padding: "lg",
    selected: p.featured,
    elevation: p.featured ? 'lg' : 'sm'
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-h3)',
      color: 'var(--text-primary)'
    }
  }, p.name), p.featured ? /*#__PURE__*/React.createElement(Badge, {
    tone: "accent",
    size: "sm"
  }, "Most teams") : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 6,
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-display)',
      fontSize: 40,
      letterSpacing: 'var(--tracking-tighter)',
      color: 'var(--text-primary)'
    }
  }, p.price), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, p.unit)), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body)',
      color: 'var(--text-secondary)',
      margin: '8px 0 16px'
    }
  }, p.desc), /*#__PURE__*/React.createElement(Button, {
    variant: p.variant,
    fullWidth: true
  }, p.cta), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      marginTop: 18,
      paddingTop: 16,
      borderTop: '1px solid var(--border-subtle)'
    }
  }, p.features.map(ft => /*#__PURE__*/React.createElement("span", {
    key: ft,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      font: 'var(--type-body)',
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 14,
    style: {
      color: 'var(--status-done)'
    }
  }), ft)))))));
}
Object.assign(window, {
  PricingPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-web/PricingPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-web/SiteChrome.jsx
try { (() => {
const {
  Button,
  Icon,
  Badge
} = window.ForgeDesignSystem_8868ce;
function SiteNav({
  route,
  setRoute
}) {
  const link = (id, label) => /*#__PURE__*/React.createElement("button", {
    key: id,
    onClick: () => setRoute(id),
    style: {
      border: 0,
      background: 'none',
      cursor: 'pointer',
      padding: '0 2px',
      font: 'var(--type-ui)',
      color: route === id ? 'var(--text-primary)' : 'var(--text-secondary)'
    }
  }, label);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 30,
      display: 'flex',
      alignItems: 'center',
      gap: 22,
      height: 58,
      padding: '0 28px',
      background: 'rgba(251,251,250,.82)',
      backdropFilter: 'var(--blur-overlay)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setRoute('home'),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      border: 0,
      background: 'none',
      cursor: 'pointer',
      padding: 0,
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: 17,
      letterSpacing: '-.03em',
      color: 'var(--text-primary)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo.svg",
    alt: "",
    width: "19",
    height: "19"
  }), "Forge"), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 18
    }
  }, link('home', 'Product'), link('pricing', 'Pricing'), link('changelog', 'Changelog'), /*#__PURE__*/React.createElement("a", {
    href: "#docs",
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-secondary)'
    }
  }, "Docs")), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("a", {
    href: "#signin",
    style: {
      font: 'var(--type-ui)',
      color: 'var(--text-secondary)'
    }
  }, "Sign in"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    iconEnd: "arrow-right"
  }, "Start free"));
}
function SiteFooter() {
  const col = (title, items) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-overline)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase',
      color: 'var(--text-disabled)'
    }
  }, title), items.map(i => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: "#",
    style: {
      font: 'var(--type-ui)',
      fontWeight: 400,
      color: 'var(--text-secondary)'
    }
  }, i)));
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: '1px solid var(--border-subtle)',
      padding: '44px 28px 32px',
      background: 'var(--surface-card)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--content-max)',
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: '1.4fr repeat(3, 1fr)',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: 17,
      letterSpacing: '-.03em',
      color: 'var(--text-primary)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo.svg",
    alt: "",
    width: "19",
    height: "19"
  }), "Forge"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)',
      maxWidth: 260,
      marginTop: 6
    }
  }, "Define the goal. Delegate the work. Watch it run.")), col('Product', ['Agents', 'Views', 'Approvals', 'Integrations']), col('Company', ['About', 'Careers', 'Blog', 'Security']), col('Resources', ['Docs', 'Changelog', 'Status', 'Contact'])), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--content-max)',
      margin: '32px auto 0',
      display: 'flex',
      gap: 14,
      font: 'var(--type-caption)',
      color: 'var(--text-disabled)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Forge Labs"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "Privacy"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "Terms")));
}
Object.assign(window, {
  SiteNav,
  SiteFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-web/SiteChrome.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.ICON_NAMES = __ds_scope.ICON_NAMES;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Kbd = __ds_scope.Kbd;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Breadcrumbs = __ds_scope.Breadcrumbs;

__ds_ns.SidebarItem = __ds_scope.SidebarItem;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.AgentRunIndicator = __ds_scope.AgentRunIndicator;

__ds_ns.ApprovalBanner = __ds_scope.ApprovalBanner;

__ds_ns.ExecutionLog = __ds_scope.ExecutionLog;

__ds_ns.STATUSES = __ds_scope.STATUSES;

__ds_ns.StatusPill = __ds_scope.StatusPill;

__ds_ns.TaskCard = __ds_scope.TaskCard;

})();
