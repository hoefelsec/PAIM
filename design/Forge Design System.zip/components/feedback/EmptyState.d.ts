/** Placeholder for an empty list, board column or search result. */
export interface EmptyStateProps {
  /** Lucide icon name. Default "inbox". */
  icon?: string;
  title?: React.ReactNode;
  description?: React.ReactNode;
  action?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function EmptyState(props: EmptyStateProps): JSX.Element;
