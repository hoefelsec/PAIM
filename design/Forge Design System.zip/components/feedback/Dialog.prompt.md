Modal for creating a task or confirming a destructive action. Approval checkpoints use `ApprovalBanner` inline instead.

```jsx
<Dialog open title="New task" description="Describe the objective." footer={<Button variant="primary">Create</Button>} onClose={close}>
  <Input label="Title" />
</Dialog>
```
