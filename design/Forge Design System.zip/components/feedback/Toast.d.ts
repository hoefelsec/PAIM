/** Transient notification, bottom-right stack. */
export interface ToastProps {
  title?: React.ReactNode;
  description?: React.ReactNode;
  tone?: 'neutral' | 'success' | 'danger' | 'agent';
  action?: React.ReactNode;
  onDismiss?: () => void;
  style?: React.CSSProperties;
}
export declare function Toast(props: ToastProps): JSX.Element;
