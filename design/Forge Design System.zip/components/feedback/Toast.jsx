import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { IconButton } from '../core/IconButton.jsx';

const TONES = {
  neutral: ['info', 'var(--text-secondary)'],
  success: ['circle-check', 'var(--success-fg)'],
  danger: ['circle-alert', 'var(--danger-fg)'],
  agent: ['sparkles', 'var(--agent-fg)'],
};

export function Toast({ title, description, tone = 'neutral', action, onDismiss, style, ...rest }) {
  const [icon, color] = TONES[tone] || TONES.neutral;
  return (
    <div style={{
      display: 'flex', gap: 10, alignItems: 'flex-start', width: 340, padding: '10px 10px 10px 12px',
      background: 'var(--surface-card)', border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)',
      animation: 'forge-rise var(--duration-normal) var(--ease-out)', ...style,
    }} {...rest}>
      <Icon name={icon} size={15} style={{ color, marginTop: 1 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: 'var(--type-ui)', color: 'var(--text-primary)' }}>{title}</div>
        {description ? <div style={{ font: 'var(--type-caption)', color: 'var(--text-secondary)', marginTop: 2 }}>{description}</div> : null}
        {action ? <div style={{ marginTop: 8 }}>{action}</div> : null}
      </div>
      {onDismiss ? <IconButton icon="x" size="sm" label="Dismiss" onClick={onDismiss} /> : null}
    </div>
  );
}
