/** Determinate or indeterminate progress track. */
export interface ProgressBarProps {
  value?: number;
  tone?: 'accent' | 'running' | 'testing' | 'reviewing' | 'paused' | 'failed' | 'done';
  size?: 'sm' | 'md' | 'lg';
  indeterminate?: boolean;
  label?: string;
  style?: React.CSSProperties;
}
export declare function ProgressBar(props: ProgressBarProps): JSX.Element;
