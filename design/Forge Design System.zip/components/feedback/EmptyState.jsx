import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function EmptyState({ icon = 'inbox', title, description, action, style, ...rest }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      gap: 6, padding: '48px 24px', textAlign: 'center', ...style,
    }} {...rest}>
      <span style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', width: 34, height: 34, marginBottom: 4,
        borderRadius: 'var(--radius-lg)', background: 'var(--surface-sunken)',
        border: '1px solid var(--border-subtle)', color: 'var(--text-tertiary)',
      }}><Icon name={icon} size={17} /></span>
      <div style={{ font: 'var(--type-h3)', fontSize: 'var(--text-md)', color: 'var(--text-primary)' }}>{title}</div>
      {description ? <div style={{ font: 'var(--type-caption)', fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)', maxWidth: 320 }}>{description}</div> : null}
      {action ? <div style={{ marginTop: 10 }}>{action}</div> : null}
    </div>
  );
}
