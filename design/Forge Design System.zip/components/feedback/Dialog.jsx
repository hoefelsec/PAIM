import React from 'react';
import { IconButton } from '../core/IconButton.jsx';

export function Dialog({ open = true, title, description, children, footer, width = 460, onClose }) {
  if (!open) return null;
  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 60, display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: 'var(--surface-overlay)', backdropFilter: 'var(--blur-overlay)', padding: 24,
      }}>
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width, maxWidth: '100%', background: 'var(--surface-card)',
          border: '1px solid var(--border-default)', borderRadius: 'var(--radius-xl)',
          boxShadow: 'var(--shadow-xl)', animation: 'forge-rise var(--duration-normal) var(--ease-out)',
        }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '16px 16px 0' }}>
          <div style={{ flex: 1 }}>
            <div style={{ font: 'var(--type-h3)', color: 'var(--text-primary)', letterSpacing: 'var(--tracking-tight)' }}>{title}</div>
            {description ? <div style={{ font: 'var(--type-caption)', fontSize: 'var(--text-sm)', color: 'var(--text-secondary)', marginTop: 4 }}>{description}</div> : null}
          </div>
          {onClose ? <IconButton icon="x" size="sm" label="Close" onClick={onClose} /> : null}
        </div>
        {children ? <div style={{ padding: '14px 16px' }}>{children}</div> : <div style={{ height: 14 }} />}
        {footer ? (
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, padding: '12px 16px', borderTop: '1px solid var(--border-subtle)' }}>{footer}</div>
        ) : null}
      </div>
    </div>
  );
}
