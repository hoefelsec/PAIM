Agent execution progress. Use `indeterminate` only while a step's duration is genuinely unknown.

```jsx
<ProgressBar value={62} label="Execution" />
```
