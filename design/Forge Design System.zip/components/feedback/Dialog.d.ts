/**
 * Centred modal for focused, interrupting decisions.
 * @startingPoint section="Feedback" subtitle="Dialog, toast, tooltip, progress" viewport="700x300"
 */
export interface DialogProps {
  open?: boolean;
  title?: React.ReactNode;
  description?: React.ReactNode;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  width?: number;
  onClose?: () => void;
}
export declare function Dialog(props: DialogProps): JSX.Element | null;
