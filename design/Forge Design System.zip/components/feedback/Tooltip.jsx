import React from 'react';
import { Kbd } from '../core/Kbd.jsx';

export function Tooltip({ children, content, shortcut, side = 'top', style, ...rest }) {
  const [open, setOpen] = React.useState(false);
  const pos = {
    top: { bottom: '100%', left: '50%', transform: 'translate(-50%,-6px)' },
    bottom: { top: '100%', left: '50%', transform: 'translate(-50%,6px)' },
    right: { left: '100%', top: '50%', transform: 'translate(6px,-50%)' },
    left: { right: '100%', top: '50%', transform: 'translate(-6px,-50%)' },
  }[side];
  return (
    <span style={{ position: 'relative', display: 'inline-flex', ...style }}
      onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)} {...rest}>
      {children}
      {open ? (
        <span style={{
          position: 'absolute', zIndex: 40, display: 'flex', alignItems: 'center', gap: 6,
          padding: '4px 7px', background: 'var(--surface-inverse)', color: 'var(--text-inverse)',
          borderRadius: 'var(--radius-sm)', boxShadow: 'var(--shadow-lg)',
          font: 'var(--type-caption)', whiteSpace: 'nowrap', pointerEvents: 'none',
          animation: 'forge-rise var(--duration-fast) var(--ease-out)', ...pos,
        }}>
          {content}
          {shortcut ? <Kbd style={{ background: 'rgba(255,255,255,.12)', borderColor: 'rgba(255,255,255,.2)', color: 'inherit' }}>{shortcut}</Kbd> : null}
        </span>
      ) : null}
    </span>
  );
}
