import React from 'react';

export function ProgressBar({ value = 0, tone = 'accent', size = 'md', indeterminate = false, label, style, ...rest }) {
  const h = size === 'sm' ? 3 : size === 'lg' ? 8 : 5;
  const color = tone === 'accent' ? 'var(--accent-solid)' : 'var(--status-' + tone + ')';
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 5, ...style }} {...rest}>
      {label ? (
        <div style={{ display: 'flex', justifyContent: 'space-between', font: 'var(--type-caption)', color: 'var(--text-tertiary)' }}>
          <span>{label}</span><span style={{ fontFamily: 'var(--font-mono)' }}>{Math.round(value)}%</span>
        </div>
      ) : null}
      <div style={{ height: h, borderRadius: 999, background: 'var(--gray-200)', overflow: 'hidden' }}>
        <div style={indeterminate ? {
          height: '100%', width: '100%', borderRadius: 999,
          background: 'linear-gradient(90deg,transparent,' + color + ',transparent)',
          backgroundSize: '200% 100%', animation: 'forge-scan 1.4s linear infinite',
        } : {
          height: '100%', width: Math.max(0, Math.min(100, value)) + '%', borderRadius: 999,
          background: color, transition: 'width var(--duration-slow) var(--ease-out)',
        }} />
      </div>
    </div>
  );
}
