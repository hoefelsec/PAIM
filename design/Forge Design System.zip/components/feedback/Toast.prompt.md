Non-blocking notice — agent finished, run failed, item archived.

```jsx
<Toast tone="agent" title="Atlas finished FRG-214" description="3 files changed · ready for review" action={<Button size="sm">Review</Button>} />
```
