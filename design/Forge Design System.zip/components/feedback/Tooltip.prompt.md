Wraps a control to explain it on hover; pass `shortcut` to teach the keybinding.

```jsx
<Tooltip content="Assign agent" shortcut="A"><IconButton icon="sparkles" label="Assign agent" /></Tooltip>
```
