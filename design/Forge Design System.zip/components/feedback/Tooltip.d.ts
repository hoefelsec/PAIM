/** Hover hint, optionally with a keyboard shortcut. */
export interface TooltipProps {
  children?: React.ReactNode;
  content?: React.ReactNode;
  shortcut?: string;
  side?: 'top' | 'bottom' | 'left' | 'right';
  style?: React.CSSProperties;
}
export declare function Tooltip(props: TooltipProps): JSX.Element;
