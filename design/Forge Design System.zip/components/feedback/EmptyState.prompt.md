Empty list or zero-results state. One line of description, one action at most.

```jsx
<EmptyState icon="list-checks" title="No tasks yet" description="Create one and delegate it to an agent." action={<Button variant="primary" icon="plus">New task</Button>} />
```
