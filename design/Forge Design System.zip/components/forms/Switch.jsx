import React from 'react';

export function Switch({ checked = false, onChange, label, size = 'md', disabled, style, ...rest }) {
  const w = size === 'sm' ? 26 : 32, h = size === 'sm' ? 15 : 18, k = h - 4;
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 8, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .5 : 1, ...style }} {...rest}>
      <span
        onClick={() => !disabled && onChange && onChange(!checked)}
        style={{
          position: 'relative', width: w, height: h, flex: 'none', borderRadius: 999,
          background: checked ? 'var(--accent-solid)' : 'var(--gray-300)',
          transition: 'background-color var(--duration-normal) var(--ease-standard)',
        }}>
        <span style={{
          position: 'absolute', top: 2, left: checked ? w - k - 2 : 2, width: k, height: k,
          borderRadius: 999, background: '#fff', boxShadow: '0 1px 2px rgba(0,0,0,.2)',
          transition: 'left var(--duration-normal) var(--ease-out)',
        }} />
      </span>
      {label ? <span style={{ font: 'var(--type-ui)', fontWeight: 'var(--weight-regular)', color: 'var(--text-body)' }}>{label}</span> : null}
    </label>
  );
}
