Multi-line field — used for agent instructions and task objectives.

```jsx
<Textarea label="Instructions" rows={5} hint="The agent reads this verbatim." />
```
