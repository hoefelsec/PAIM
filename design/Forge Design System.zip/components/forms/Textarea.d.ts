/** Multi-line text field for objectives and instructions. */
export interface TextareaProps {
  label?: string;
  hint?: string;
  rows?: number;
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  disabled?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  style?: React.CSSProperties;
}
export declare function Textarea(props: TextareaProps): JSX.Element;
