Text field with optional label, leading icon and hint/error line.

```jsx
<Input label="Task title" placeholder="Summarise the objective" />
<Input icon="search" placeholder="Search tasks" size="sm" />
```

`error` replaces `hint` and turns the border red. Focus ring is the ember `--focus-ring`.
