/**
 * Single-line text field.
 * @startingPoint section="Forms" subtitle="Text fields, selects, toggles" viewport="700x260"
 */
export interface InputProps {
  label?: string;
  hint?: string;
  error?: string;
  /** Lucide icon name shown inside the field. */
  icon?: string;
  suffix?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg';
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  disabled?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  style?: React.CSSProperties;
}
export declare function Input(props: InputProps): JSX.Element;
