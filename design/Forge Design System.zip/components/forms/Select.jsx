import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function Select({ label, options = [], value, onChange, size = 'md', disabled, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const h = size === 'sm' ? 'var(--control-height-sm)' : 'var(--control-height-md)';
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 5, ...style }}>
      {label ? <span style={{ font: 'var(--type-ui)', color: 'var(--text-body)' }}>{label}</span> : null}
      <span style={{
        position: 'relative', display: 'flex', alignItems: 'center', height: h,
        background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
        border: '1px solid ' + (focus ? 'var(--border-focus)' : 'var(--border-default)'),
        borderRadius: 'var(--radius-md)', boxShadow: focus ? 'var(--focus-ring)' : 'none',
        transition: 'var(--transition-control)',
      }}>
        <select
          value={value} disabled={disabled}
          onChange={e => onChange && onChange(e.target.value)}
          onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          style={{
            appearance: 'none', width: '100%', height: '100%', padding: '0 28px 0 9px',
            border: 0, outline: 'none', background: 'transparent', cursor: disabled ? 'not-allowed' : 'pointer',
            font: 'var(--type-body)', fontSize: 'var(--text-sm)', color: 'var(--text-primary)',
          }}
          {...rest}
        >
          {options.map(o => {
            const opt = typeof o === 'string' ? { value: o, label: o } : o;
            return <option key={opt.value} value={opt.value}>{opt.label}</option>;
          })}
        </select>
        <Icon name="chevron-down" size={14} style={{ position: 'absolute', right: 8, color: 'var(--text-tertiary)', pointerEvents: 'none' }} />
      </span>
    </label>
  );
}
