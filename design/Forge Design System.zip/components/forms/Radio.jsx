import React from 'react';

export function Radio({ checked = false, onChange, label, description, disabled, style, ...rest }) {
  return (
    <label style={{ display: 'flex', gap: 8, alignItems: description ? 'flex-start' : 'center', cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .5 : 1, ...style }} {...rest}>
      <span
        onClick={() => !disabled && onChange && onChange(true)}
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none',
          width: 16, height: 16, marginTop: description ? 1 : 0, borderRadius: 'var(--radius-full)',
          background: 'var(--surface-card)',
          border: '1px solid ' + (checked ? 'var(--accent-solid)' : 'var(--border-strong)'),
          transition: 'var(--transition-control)',
        }}>
        {checked ? <span style={{ width: 7, height: 7, borderRadius: 999, background: 'var(--accent-solid)' }} /> : null}
      </span>
      {label || description ? (
        <span style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {label ? <span style={{ font: 'var(--type-ui)', fontWeight: 'var(--weight-regular)', color: 'var(--text-body)' }}>{label}</span> : null}
          {description ? <span style={{ font: 'var(--type-caption)', color: 'var(--text-tertiary)' }}>{description}</span> : null}
        </span>
      ) : null}
    </label>
  );
}
