import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function Checkbox({ checked = false, indeterminate = false, onChange, label, description, disabled, style, ...rest }) {
  const on = checked || indeterminate;
  return (
    <label style={{ display: 'flex', gap: 8, alignItems: description ? 'flex-start' : 'center', cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .5 : 1, ...style }} {...rest}>
      <span
        onClick={() => !disabled && onChange && onChange(!checked)}
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none',
          width: 16, height: 16, marginTop: description ? 1 : 0, borderRadius: 'var(--radius-xs)',
          background: on ? 'var(--accent-solid)' : 'var(--surface-card)',
          border: '1px solid ' + (on ? 'var(--accent-solid)' : 'var(--border-strong)'),
          color: '#fff', transition: 'var(--transition-control)',
        }}>
        {indeterminate ? <Icon name="minus" size={11} /> : checked ? <Icon name="check" size={11} /> : null}
      </span>
      {label || description ? (
        <span style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {label ? <span style={{ font: 'var(--type-ui)', fontWeight: 'var(--weight-regular)', color: 'var(--text-body)' }}>{label}</span> : null}
          {description ? <span style={{ font: 'var(--type-caption)', color: 'var(--text-tertiary)' }}>{description}</span> : null}
        </span>
      ) : null}
    </label>
  );
}
