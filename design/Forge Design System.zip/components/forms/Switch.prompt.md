Toggle for settings that apply immediately (no Save button).

```jsx
<Switch checked={auto} onChange={setAuto} label="Auto-advance status" />
```
