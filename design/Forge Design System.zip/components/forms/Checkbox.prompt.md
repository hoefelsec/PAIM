Multi-select and bulk-action control.

```jsx
<Checkbox checked={on} onChange={setOn} label="Require approval before publishing" />
```
