import React from 'react';

export function Textarea({ label, hint, rows = 4, disabled, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 5, ...style }}>
      {label ? <span style={{ font: 'var(--type-ui)', color: 'var(--text-body)' }}>{label}</span> : null}
      <textarea
        rows={rows} disabled={disabled}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{
          resize: 'vertical', padding: '8px 9px', background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
          border: '1px solid ' + (focus ? 'var(--border-focus)' : 'var(--border-default)'),
          borderRadius: 'var(--radius-md)', boxShadow: focus ? 'var(--focus-ring)' : 'none',
          outline: 'none', font: 'var(--type-body)', fontSize: 'var(--text-sm)', color: 'var(--text-primary)',
          transition: 'var(--transition-control)',
        }}
        {...rest}
      />
      {hint ? <span style={{ font: 'var(--type-caption)', color: 'var(--text-tertiary)' }}>{hint}</span> : null}
    </label>
  );
}
