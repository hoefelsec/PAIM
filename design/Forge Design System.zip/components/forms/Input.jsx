import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function Input({ label, hint, error, icon, suffix, size = 'md', disabled, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const h = size === 'sm' ? 'var(--control-height-sm)' : size === 'lg' ? 'var(--control-height-lg)' : 'var(--control-height-md)';
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 5, ...style }}>
      {label ? <span style={{ font: 'var(--type-ui)', color: 'var(--text-body)' }}>{label}</span> : null}
      <span style={{
        display: 'flex', alignItems: 'center', gap: 6, height: h, padding: '0 9px',
        background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
        border: '1px solid ' + (error ? 'var(--danger-solid)' : focus ? 'var(--border-focus)' : 'var(--border-default)'),
        borderRadius: 'var(--radius-md)', boxShadow: focus ? 'var(--focus-ring)' : 'none',
        transition: 'var(--transition-control)',
      }}>
        {icon ? <Icon name={icon} size={14} style={{ color: 'var(--text-tertiary)' }} /> : null}
        <input
          disabled={disabled}
          onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          style={{
            flex: 1, minWidth: 0, border: 0, outline: 'none', background: 'transparent',
            font: 'var(--type-body)', fontSize: size === 'sm' ? 'var(--text-xs)' : 'var(--text-sm)',
            color: 'var(--text-primary)',
          }}
          {...rest}
        />
        {suffix ? <span style={{ font: 'var(--type-caption)', color: 'var(--text-tertiary)' }}>{suffix}</span> : null}
      </span>
      {error || hint ? (
        <span style={{ font: 'var(--type-caption)', color: error ? 'var(--danger-fg)' : 'var(--text-tertiary)' }}>{error || hint}</span>
      ) : null}
    </label>
  );
}
