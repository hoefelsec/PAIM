Dropdown for closed option sets (model, priority, view).

```jsx
<Select label="Model" options={['Claude Sonnet 4.5','GPT-5','Local Llama']} value={m} onChange={setM} />
```
