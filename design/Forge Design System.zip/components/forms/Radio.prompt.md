Exclusive choice, 2–4 options with descriptions.

```jsx
<Radio checked={mode === 'auto'} onChange={() => setMode('auto')} label="Autonomous" description="Agent runs to completion." />
```
