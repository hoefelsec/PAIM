/** Workspace › project › task trail. */
export interface BreadcrumbsProps {
  items?: Array<{ label: React.ReactNode; icon?: string; onClick?: () => void }>;
  style?: React.CSSProperties;
}
export declare function Breadcrumbs(props: BreadcrumbsProps): JSX.Element;
