import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function Tabs({ tabs = [], value, onChange, variant = 'underline', style, ...rest }) {
  const active = value != null ? value : (tabs[0] && tabs[0].value);
  const pill = variant === 'pill';
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: pill ? 2 : 2,
      padding: pill ? 2 : 0, background: pill ? 'var(--surface-sunken)' : 'transparent',
      border: pill ? '1px solid var(--border-subtle)' : 0,
      borderBottom: pill ? '1px solid var(--border-subtle)' : '1px solid var(--border-default)',
      borderRadius: pill ? 'var(--radius-md)' : 0, ...style,
    }} {...rest}>
      {tabs.map(t => {
        const on = t.value === active;
        return (
          <button key={t.value} type="button" onClick={() => onChange && onChange(t.value)}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 6, height: pill ? 24 : 30,
              padding: pill ? '0 9px' : '0 8px', border: 0, background: on && pill ? 'var(--surface-card)' : 'transparent',
              borderRadius: pill ? 'var(--radius-sm)' : 0, boxShadow: on && pill ? 'var(--shadow-xs)' : 'none',
              borderBottom: pill ? 'none' : '2px solid ' + (on ? 'var(--accent-solid)' : 'transparent'),
              marginBottom: pill ? 0 : -1, cursor: 'pointer',
              font: 'var(--type-ui)', color: on ? 'var(--text-primary)' : 'var(--text-tertiary)',
              transition: 'var(--transition-control)',
            }}>
            {t.icon ? <Icon name={t.icon} size={14} /> : null}
            {t.label}
            {t.count != null ? (
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-tertiary)' }}>{t.count}</span>
            ) : null}
          </button>
        );
      })}
    </div>
  );
}
