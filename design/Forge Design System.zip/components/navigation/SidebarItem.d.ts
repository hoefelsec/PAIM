/** Row in the workspace sidebar. */
export interface SidebarItemProps {
  /** Lucide icon name. */
  icon?: string;
  label?: React.ReactNode;
  active?: boolean;
  count?: number;
  /** Nesting level; each level indents 14px. */
  indent?: number;
  /** Renders a colour square instead of an icon (projects). */
  dot?: string;
  onClick?: () => void;
  style?: React.CSSProperties;
}
export declare function SidebarItem(props: SidebarItemProps): JSX.Element;
