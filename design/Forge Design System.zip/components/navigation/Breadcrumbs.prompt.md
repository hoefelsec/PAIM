Location trail in a page header; last item is the current page and is not a link.

```jsx
<Breadcrumbs items={[{label:'Northwind', icon:'building-2'},{label:'Forge Web'},{label:'FRG-214'}]} />
```
