Sidebar navigation row — 28px tall, icon or project colour dot, optional count.

```jsx
<SidebarItem icon="inbox" label="Inbox" count={4} />
<SidebarItem dot="var(--ember-500)" label="Forge Web" indent={1} active />
```
