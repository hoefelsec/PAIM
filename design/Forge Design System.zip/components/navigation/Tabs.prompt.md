Switches between views of the same object (List / Board / Calendar / Timeline).

```jsx
<Tabs tabs={[{value:'list',label:'List',icon:'list'},{value:'board',label:'Board',icon:'columns-3'}]} value={v} onChange={setV} />
```
