/**
 * View switcher.
 * @startingPoint section="Navigation" subtitle="Tabs, sidebar items, breadcrumbs" viewport="700x220"
 */
export interface TabsProps {
  tabs?: Array<{ value: string; label: string; icon?: string; count?: number }>;
  value?: string;
  onChange?: (value: string) => void;
  /** underline = page-level; pill = inside a panel. */
  variant?: 'underline' | 'pill';
  style?: React.CSSProperties;
}
export declare function Tabs(props: TabsProps): JSX.Element;
