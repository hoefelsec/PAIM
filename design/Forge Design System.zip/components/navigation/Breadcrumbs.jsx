import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function Breadcrumbs({ items = [], style, ...rest }) {
  return (
    <nav style={{ display: 'flex', alignItems: 'center', gap: 4, ...style }} {...rest}>
      {items.map((it, i) => (
        <React.Fragment key={i}>
          {i > 0 ? <Icon name="chevron-right" size={13} style={{ color: 'var(--text-disabled)' }} /> : null}
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 5, font: 'var(--type-ui)',
            color: i === items.length - 1 ? 'var(--text-primary)' : 'var(--text-tertiary)',
            cursor: it.onClick ? 'pointer' : 'default',
          }} onClick={it.onClick}>
            {it.icon ? <Icon name={it.icon} size={13} /> : null}{it.label}
          </span>
        </React.Fragment>
      ))}
    </nav>
  );
}
