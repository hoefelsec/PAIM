import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function SidebarItem({ icon, label, active = false, count, indent = 0, dot, onClick, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  return (
    <button type="button" onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 8, width: '100%', height: 28,
        padding: '0 8px 0 ' + (8 + indent * 14) + 'px', border: 0, textAlign: 'left',
        background: active ? 'var(--surface-active)' : hover ? 'var(--surface-hover)' : 'transparent',
        borderRadius: 'var(--radius-sm)', cursor: 'pointer',
        font: 'var(--type-ui)', color: active ? 'var(--text-primary)' : 'var(--text-secondary)',
        transition: 'var(--transition-control)', ...style,
      }} {...rest}>
      {dot ? <span style={{ width: 6, height: 6, borderRadius: 2, background: dot, flex: 'none' }} />
        : icon ? <Icon name={icon} size={14} style={{ color: active ? 'var(--text-accent)' : 'var(--text-tertiary)' }} /> : null}
      <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{label}</span>
      {count != null ? <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-tertiary)' }}>{count}</span> : null}
    </button>
  );
}
