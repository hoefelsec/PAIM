import React from 'react';
import { Icon } from './Icon.jsx';

export function Tag({ children, color = 'var(--gray-400)', onRemove, style, ...rest }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5, height: 20, padding: '0 7px',
      background: 'var(--surface-card)', border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-sm)', color: 'var(--text-secondary)',
      fontFamily: 'var(--font-sans)', fontSize: 'var(--text-xs)', fontWeight: 'var(--weight-medium)', ...style,
    }} {...rest}>
      <span style={{ width: 6, height: 6, borderRadius: 2, background: color }} />
      {children}
      {onRemove ? (
        <button type="button" onClick={onRemove} aria-label="Remove"
          style={{ display: 'flex', border: 0, background: 'none', padding: 0, marginRight: -2, color: 'var(--text-tertiary)', cursor: 'pointer' }}>
          <Icon name="x" size={11} />
        </button>
      ) : null}
    </span>
  );
}
