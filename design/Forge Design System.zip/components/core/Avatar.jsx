import React from 'react';
import { Icon } from './Icon.jsx';

const SIZES = { xs: 18, sm: 22, md: 28, lg: 36 };

/* kind="agent" renders the ember-ringed AI identity; kind="user" renders initials or a photo. */
export function Avatar({ name = '', src, kind = 'user', size = 'md', status, style, ...rest }) {
  const px = SIZES[size] || SIZES.md;
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  const agent = kind === 'agent';
  return (
    <span style={{ position: 'relative', display: 'inline-flex', flex: 'none', ...style }} title={name} {...rest}>
      <span style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', width: px, height: px,
        borderRadius: agent ? 'var(--radius-sm)' : 'var(--radius-full)', overflow: 'hidden',
        background: agent ? 'var(--agent-bg)' : 'var(--gray-100)',
        border: '1px solid ' + (agent ? 'var(--agent-border)' : 'var(--border-default)'),
        color: agent ? 'var(--agent-fg)' : 'var(--text-secondary)',
        fontFamily: 'var(--font-sans)', fontSize: Math.round(px * .38), fontWeight: 'var(--weight-semibold)',
      }}>
        {src ? <img src={src} alt={name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          : agent ? <Icon name="sparkles" size={Math.round(px * .55)} /> : initials}
      </span>
      {status ? (
        <span style={{
          position: 'absolute', right: -1, bottom: -1, width: Math.max(7, px * .28), height: Math.max(7, px * .28),
          borderRadius: 999, background: 'var(--status-' + status + ')', border: '2px solid var(--surface-card)',
        }} />
      ) : null}
    </span>
  );
}
