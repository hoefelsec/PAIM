import React from 'react';

const PAD = { none: 0, sm: 'var(--space-5)', md: 'var(--space-6)', lg: 'var(--space-8)' };

export function Card({ children, padding = 'md', elevation = 'sm', interactive = false, selected = false, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const shadow = { none: 'none', sm: 'var(--shadow-sm)', md: 'var(--shadow-md)', lg: 'var(--shadow-lg)' }[elevation];
  return (
    <div
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        background: 'var(--surface-card)', borderRadius: 'var(--radius-lg)',
        border: '1px solid ' + (selected ? 'var(--border-accent)' : 'var(--border-default)'),
        boxShadow: selected ? 'var(--shadow-md)' : shadow, padding: PAD[padding],
        transition: 'box-shadow var(--duration-normal) var(--ease-standard), border-color var(--duration-fast) var(--ease-standard), transform var(--duration-normal) var(--ease-standard)',
        cursor: interactive ? 'pointer' : undefined,
        ...(interactive && hover ? { boxShadow: 'var(--shadow-md)', transform: 'translateY(-1px)' } : null),
        ...style,
      }}
      {...rest}
    >{children}</div>
  );
}
