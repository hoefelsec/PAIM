/** Removable label chip with a colour key. */
export interface TagProps {
  children?: React.ReactNode;
  /** Swatch colour; any CSS colour or token. */
  color?: string;
  onRemove?: () => void;
  style?: React.CSSProperties;
}
export declare function Tag(props: TagProps): JSX.Element;
