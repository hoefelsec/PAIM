Identity mark. Agents are square + ember; humans are round + neutral — this shape difference is the fastest read of who did the work.

```jsx
<Avatar name="Mara Vidal" size="sm" />
<Avatar name="Atlas" kind="agent" size="sm" status="running" />
```
