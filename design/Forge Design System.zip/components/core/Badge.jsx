import React from 'react';
import { Icon } from './Icon.jsx';

const TONES = {
  neutral: ['var(--surface-sunken)', 'var(--text-secondary)', 'var(--border-default)'],
  accent: ['var(--accent-soft)', 'var(--text-accent)', 'var(--accent-soft-border)'],
  success: ['var(--success-bg)', 'var(--success-fg)', 'transparent'],
  warning: ['var(--warning-bg)', 'var(--warning-fg)', 'transparent'],
  danger: ['var(--danger-bg)', 'var(--danger-fg)', 'transparent'],
  info: ['var(--info-bg)', 'var(--info-fg)', 'transparent'],
  solid: ['var(--accent-solid)', 'var(--accent-on-solid)', 'transparent'],
};

export function Badge({ children, tone = 'neutral', icon, dot = false, size = 'md', style, ...rest }) {
  const [bg, fg, bd] = TONES[tone] || TONES.neutral;
  const sm = size === 'sm';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: sm ? 4 : 5,
      height: sm ? 18 : 22, padding: sm ? '0 6px' : '0 8px',
      background: bg, color: fg, border: '1px solid ' + bd,
      borderRadius: 'var(--radius-full)', fontFamily: 'var(--font-sans)',
      fontSize: sm ? 'var(--text-2xs)' : 'var(--text-xs)', fontWeight: 'var(--weight-medium)',
      letterSpacing: 'var(--tracking-tight)', whiteSpace: 'nowrap', ...style,
    }} {...rest}>
      {dot ? <span style={{ width: 5, height: 5, borderRadius: 999, background: 'currentColor' }} /> : null}
      {icon ? <Icon name={icon} size={sm ? 11 : 12} /> : null}
      {children}
    </span>
  );
}
