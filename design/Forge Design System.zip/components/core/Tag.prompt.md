Task label chip — square colour key plus name.

```jsx
<Tag color="var(--violet-500)">design</Tag>
<Tag color="var(--blue-500)" onRemove={() => {}}>infra</Tag>
```
