/**
 * Neutral surface container.
 * @startingPoint section="Core" subtitle="Surface container with hairline border" viewport="700x200"
 */
export interface CardProps {
  children?: React.ReactNode;
  padding?: 'none' | 'sm' | 'md' | 'lg';
  elevation?: 'none' | 'sm' | 'md' | 'lg';
  /** Adds hover lift + pointer cursor. */
  interactive?: boolean;
  selected?: boolean;
  style?: React.CSSProperties;
}
export declare function Card(props: CardProps): JSX.Element;
