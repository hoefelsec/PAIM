Generic Forge surface: white, 10px radius, hairline border, near-invisible shadow.

```jsx
<Card padding="md"><h3>Project health</h3></Card>
```

Use `interactive` only when the whole card is a click target. `selected` swaps the border to ember — never a fill.
