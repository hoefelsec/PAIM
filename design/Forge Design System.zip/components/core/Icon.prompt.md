Renders a single Lucide glyph that inherits `currentColor`; use it for every icon in Forge instead of inline SVG.

```jsx
<Icon name="sparkles" size={14} style={{ color: 'var(--text-accent)' }} />
```

Names are Lucide kebab-case and must be one of the 55 glyphs bundled in `Icon.jsx` (source files in `assets/icons/`; `ICON_NAMES` lists them). Add a glyph by dropping its Lucide SVG into `assets/icons/` and adding it to the map — never by pointing at a CDN. Forge's core glyph vocabulary: `sparkles` (agent), `play`/`pause` (execution), `terminal` (logs), `shield-check` (approval), `circle-dashed`/`circle`/`loader-circle`/`circle-check` (lifecycle), `signal-high`/`signal-medium`/`signal-low` (priority).
