Icon-only button for toolbars, table rows and panel headers. Always pass `label`.

```jsx
<IconButton icon="filter" label="Filter" />
<IconButton icon="layout-grid" label="Board view" active />
```

Ghost by default; `variant="secondary"` adds the hairline border when it sits outside a toolbar cluster.
