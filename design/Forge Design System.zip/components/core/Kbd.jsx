import React from 'react';

/* Forge is keyboard-first; shortcuts are shown inline everywhere. */
export function Kbd({ children, style, ...rest }) {
  return (
    <kbd style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      minWidth: 18, height: 18, padding: '0 4px',
      background: 'var(--surface-sunken)', border: '1px solid var(--border-default)',
      borderBottomWidth: 2, borderRadius: 'var(--radius-xs)',
      fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', fontWeight: 'var(--weight-medium)',
      color: 'var(--text-tertiary)', ...style,
    }} {...rest}>{children}</kbd>
  );
}
