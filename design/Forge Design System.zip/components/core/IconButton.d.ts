/** Square icon-only control for toolbars and row affordances. */
export interface IconButtonProps {
  /** Lucide icon name. */
  icon: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'ghost' | 'secondary';
  active?: boolean;
  disabled?: boolean;
  /** Accessible name; also used as the native title. */
  label?: string;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
