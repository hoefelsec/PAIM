export interface IconProps {
  /** Lucide icon name in kebab-case, e.g. "circle-check". */
  name: string;
  /** Pixel box. Default 16. */
  size?: number;
  style?: React.CSSProperties;
  className?: string;
}
export declare function Icon(props: IconProps): JSX.Element;
/** Every glyph name bundled with the system. */
export declare const ICON_NAMES: string[];
