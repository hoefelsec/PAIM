import React from 'react';
import { Icon } from './Icon.jsx';

const SIZES = {
  sm: { height: 'var(--control-height-sm)', padding: '0 8px', font: 'var(--text-xs)', gap: 5, icon: 13 },
  md: { height: 'var(--control-height-md)', padding: '0 11px', font: 'var(--text-sm)', gap: 6, icon: 15 },
  lg: { height: 'var(--control-height-lg)', padding: '0 15px', font: 'var(--text-md)', gap: 7, icon: 16 },
};

const VARIANTS = {
  primary: { background: 'var(--accent-solid)', color: 'var(--accent-on-solid)', border: '1px solid transparent', boxShadow: 'var(--shadow-xs)' },
  secondary: { background: 'var(--surface-card)', color: 'var(--text-primary)', border: '1px solid var(--border-default)', boxShadow: 'var(--shadow-xs)' },
  ghost: { background: 'transparent', color: 'var(--text-secondary)', border: '1px solid transparent' },
  danger: { background: 'var(--danger-solid)', color: '#fff', border: '1px solid transparent' },
  inverse: { background: 'var(--surface-inverse)', color: 'var(--text-inverse)', border: '1px solid transparent' },
};

const HOVER = {
  primary: { background: 'var(--accent-solid-hover)' },
  secondary: { background: 'var(--surface-hover)' },
  ghost: { background: 'var(--surface-hover)', color: 'var(--text-primary)' },
  danger: { background: 'var(--red-600)' },
  inverse: { opacity: .88 },
};

export function Button({
  children, variant = 'secondary', size = 'md', icon, iconEnd, loading = false,
  disabled = false, fullWidth = false, onClick, type = 'button', style, ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [down, setDown] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.secondary;
  const off = disabled || loading;
  return (
    <button
      type={type}
      disabled={off}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setDown(false); }}
      onMouseDown={() => setDown(true)}
      onMouseUp={() => setDown(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        gap: s.gap, height: s.height, padding: s.padding, width: fullWidth ? '100%' : undefined,
        fontFamily: 'var(--font-sans)', fontSize: s.font, fontWeight: 'var(--weight-medium)',
        letterSpacing: 'var(--tracking-tight)', borderRadius: 'var(--radius-md)',
        cursor: off ? 'not-allowed' : 'pointer', opacity: off ? .45 : 1,
        transition: 'var(--transition-control), transform var(--duration-instant) var(--ease-standard)',
        transform: down && !off ? 'scale(.985)' : 'none',
        ...v, ...(hover && !off ? HOVER[variant] : null), ...style,
      }}
      {...rest}
    >
      {loading
        ? <Icon name="loader-circle" size={s.icon} style={{ animation: 'forge-spin 900ms linear infinite' }} />
        : icon ? <Icon name={icon} size={s.icon} /> : null}
      {children}
      {iconEnd ? <Icon name={iconEnd} size={s.icon} /> : null}
    </button>
  );
}
