Shows a keyboard key. Forge is keyboard-first — surface the shortcut wherever the action is named.

```jsx
Assign agent <Kbd>A</Kbd>
```
