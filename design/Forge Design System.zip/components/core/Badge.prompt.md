Read-only status or count pill.

```jsx
<Badge tone="accent" icon="sparkles">Agent</Badge>
<Badge tone="success" dot>Passing</Badge>
```

For task lifecycle state use `StatusPill` instead — Badge is for everything else (plan tier, env, counts).
