/**
 * Primary action control.
 * @startingPoint section="Core" subtitle="Buttons in every variant, size and state" viewport="700x180"
 */
export interface ButtonProps {
  children?: React.ReactNode;
  /** primary = the single ember action per view. Default "secondary". */
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'inverse';
  size?: 'sm' | 'md' | 'lg';
  /** Lucide icon name rendered before the label. */
  icon?: string;
  /** Lucide icon name rendered after the label. */
  iconEnd?: string;
  loading?: boolean;
  disabled?: boolean;
  fullWidth?: boolean;
  type?: 'button' | 'submit' | 'reset';
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
