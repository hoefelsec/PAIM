Standard Forge button — use `primary` for the one committing action on a view, `secondary` for everything else.

```jsx
<Button variant="primary" icon="play">Run task</Button>
<Button variant="secondary" size="sm">Cancel</Button>
<Button variant="ghost" icon="ellipsis" />
```

Variants: primary (ember fill), secondary (white + hairline), ghost (toolbar), danger, inverse. Sizes sm/md/lg map to the 26/32/38px control heights. `loading` swaps the leading icon for a spinner and disables the control.
