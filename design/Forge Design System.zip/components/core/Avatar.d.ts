/** Identity mark for a human or an AI agent. */
export interface AvatarProps {
  name?: string;
  src?: string;
  /** "agent" renders the ember square mark; "user" renders a round photo/initials. */
  kind?: 'user' | 'agent';
  size?: 'xs' | 'sm' | 'md' | 'lg';
  /** Adds a lifecycle dot in the corner. */
  status?: 'open-questions' | 'design' | 'ready' | 'running' | 'testing' | 'reviewing' | 'paused' | 'failed' | 'canceled' | 'done';
  style?: React.CSSProperties;
}
export declare function Avatar(props: AvatarProps): JSX.Element;
