import React from 'react';
import { Icon } from './Icon.jsx';

const SIZES = { sm: [26, 14], md: [32, 16], lg: [38, 18] };

export function IconButton({ icon, size = 'md', variant = 'ghost', active = false, disabled = false, label, onClick, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const [box, glyph] = SIZES[size] || SIZES.md;
  const base = variant === 'secondary'
    ? { background: 'var(--surface-card)', border: '1px solid var(--border-default)' }
    : { background: 'transparent', border: '1px solid transparent' };
  return (
    <button
      type="button" aria-label={label} title={label} disabled={disabled} onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        width: box, height: box, borderRadius: 'var(--radius-md)', flex: 'none',
        color: active ? 'var(--text-accent)' : 'var(--text-secondary)',
        cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .45 : 1,
        transition: 'var(--transition-control)', ...base,
        ...(active ? { background: 'var(--surface-selected)' } : null),
        ...(hover && !disabled ? { background: 'var(--surface-hover)', color: 'var(--text-primary)' } : null),
        ...style,
      }}
      {...rest}
    >
      <Icon name={icon} size={glyph} />
    </button>
  );
}
