/** Inline human checkpoint gating agent output. */
export interface ApprovalBannerProps {
  title?: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  tone?: 'accent' | 'warning';
  style?: React.CSSProperties;
}
export declare function ApprovalBanner(props: ApprovalBannerProps): JSX.Element;
