Ember pill showing an agent is on the job — the only element in Forge that animates continuously.

```jsx
<AgentRunIndicator agent="Atlas" step="running tests" elapsed="2m 14s" />
```

`compact` for card footers and table rows; `state="paused"` freezes the pulse and shows a pause glyph.
