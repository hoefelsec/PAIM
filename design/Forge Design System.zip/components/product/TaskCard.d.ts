/** Board/list unit of work. */
export interface TaskCardProps {
  /** Short key, e.g. "FRG-214". */
  id?: string;
  title?: React.ReactNode;
  status?: 'open-questions' | 'design' | 'ready' | 'running' | 'testing' | 'reviewing' | 'paused' | 'failed' | 'canceled' | 'done';
  priority?: 'urgent' | 'high' | 'medium' | 'low';
  labels?: Array<{ name: string; color: string }>;
  /** Human assignee name. */
  assignee?: string;
  /** Agent name; when set, replaces the status pill with a live agent pill. */
  agent?: string;
  /** 0–100; renders a progress track when an agent is assigned. */
  progress?: number;
  due?: string;
  comments?: number;
  attachments?: number;
  selected?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
}
export declare function TaskCard(props: TaskCardProps): JSX.Element;
