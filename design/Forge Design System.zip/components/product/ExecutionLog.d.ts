/** Streaming agent activity log. */
export interface ExecutionLogProps {
  entries?: Array<{ time: string; level: 'tool' | 'info' | 'ok' | 'warn' | 'error'; message: string }>;
  /** Shows the pulsing "live" marker. */
  live?: boolean;
  /** Max scroll height in px. Default 240. */
  height?: number;
  style?: React.CSSProperties;
}
export declare function ExecutionLog(props: ExecutionLogProps): JSX.Element;
