/**
 * Task lifecycle state.
 * @startingPoint section="Execution" subtitle="Status, agent run, task card, log, approval" viewport="700x340"
 */
export interface StatusPillProps {
  status?: 'open-questions' | 'design' | 'ready' | 'running' | 'testing' | 'reviewing' | 'paused' | 'failed' | 'canceled' | 'done';
  showLabel?: boolean;
  size?: 'sm' | 'md';
  style?: React.CSSProperties;
}
export declare function StatusPill(props: StatusPillProps): JSX.Element;
export declare const STATUSES: Record<string, { label: string; icon: string; color: string }>;
