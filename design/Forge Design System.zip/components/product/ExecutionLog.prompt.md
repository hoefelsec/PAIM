Dark, monospace record of every agent action — Forge's transparency guarantee. Never summarise or hide entries.

```jsx
<ExecutionLog live entries={[{time:'14:02:11',level:'tool',message:'read_file("billing/webhooks.ts")'}]} />
```

Levels: tool (ember) · info · ok · warn · error.
