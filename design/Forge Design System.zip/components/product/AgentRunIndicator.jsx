import React from 'react';
import { Icon } from '../core/Icon.jsx';

/* Shows that an AI agent is actively executing — the one place the ember accent animates. */
export function AgentRunIndicator({ agent = 'Agent', step, elapsed, state = 'running', compact = false, style, ...rest }) {
  const running = state === 'running';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 7, height: compact ? 20 : 24,
      padding: compact ? '0 7px' : '0 9px', background: 'var(--agent-bg)',
      border: '1px solid var(--agent-border)', borderRadius: 'var(--radius-full)',
      color: 'var(--agent-fg)', font: 'var(--type-ui)', fontSize: compact ? 'var(--text-2xs)' : 'var(--text-xs)',
      whiteSpace: 'nowrap', ...style,
    }} {...rest}>
      <span style={{ position: 'relative', display: 'flex', width: 6, height: 6 }}>
        {running ? <span style={{
          position: 'absolute', inset: -3, borderRadius: 999, background: 'var(--agent-pulse)',
          animation: 'forge-pulse var(--duration-pulse) var(--ease-standard) infinite',
        }} /> : null}
        <span style={{ width: 6, height: 6, borderRadius: 999, background: 'currentColor' }} />
      </span>
      {agent}
      {step ? <span style={{ color: 'var(--text-tertiary)', fontWeight: 'var(--weight-regular)' }}>{step}</span> : null}
      {elapsed ? <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-tertiary)' }}>{elapsed}</span> : null}
      {state === 'paused' ? <Icon name="pause" size={11} /> : null}
    </span>
  );
}
