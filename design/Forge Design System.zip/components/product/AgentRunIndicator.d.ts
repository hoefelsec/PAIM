/** Live indicator that an AI agent is executing. */
export interface AgentRunIndicatorProps {
  /** Agent name, e.g. "Atlas". */
  agent?: string;
  /** Current step summary, e.g. "reading spec". */
  step?: string;
  /** Elapsed time string, e.g. "2m 14s". */
  elapsed?: string;
  state?: 'running' | 'paused' | 'idle';
  compact?: boolean;
  style?: React.CSSProperties;
}
export declare function AgentRunIndicator(props: AgentRunIndicatorProps): JSX.Element;
