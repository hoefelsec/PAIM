The canonical task-status indicator. Never re-map these ten states or their colours.

```jsx
<StatusPill status="running" />
<StatusPill status="done" showLabel={false} size="sm" />
```

open-questions (amber) · design (violet) · ready (grey) · running (ember, spins) · testing (light ember) · reviewing (blue) · paused (dark amber) · failed (red) · canceled (grey, dimmest) · done (green).

The three grey-family states read as "not moving": `ready` waits to start, `paused` was stopped deliberately, `canceled` will never run.
