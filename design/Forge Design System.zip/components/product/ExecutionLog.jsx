import React from 'react';
import { Icon } from '../core/Icon.jsx';

const LEVEL = { tool: 'var(--ember-400)', info: 'var(--log-dim)', ok: 'var(--green-500)', warn: 'var(--amber-500)', error: 'var(--red-500)' };

/* Streaming record of everything an agent did. Monospace, dark, timestamped, never truncated silently. */
export function ExecutionLog({ entries = [], live = false, height = 240, style, ...rest }) {
  return (
    <div style={{
      background: 'var(--log-surface)', borderRadius: 'var(--radius-lg)',
      border: '1px solid var(--border-default)', overflow: 'hidden', ...style,
    }} {...rest}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 7, padding: '7px 10px',
        borderBottom: '1px solid rgba(255,255,255,.08)', color: 'var(--log-dim)',
        font: 'var(--type-overline)', letterSpacing: 'var(--tracking-caps)', textTransform: 'uppercase',
      }}>
        <Icon name="terminal" size={12} />Execution log
        {live ? <span style={{ marginLeft: 'auto', display: 'inline-flex', alignItems: 'center', gap: 5, color: 'var(--ember-400)' }}>
          <span style={{ width: 5, height: 5, borderRadius: 999, background: 'currentColor', animation: 'forge-pulse var(--duration-pulse) infinite' }} />live
        </span> : null}
      </div>
      <div style={{ maxHeight: height, overflow: 'auto', padding: '8px 10px', font: 'var(--type-mono)', color: 'var(--log-text)' }}>
        {entries.map((e, i) => (
          <div key={i} style={{ display: 'flex', gap: 10, padding: '2px 0' }}>
            <span style={{ color: 'var(--log-dim)', flex: 'none' }}>{e.time}</span>
            <span style={{ color: LEVEL[e.level] || 'var(--log-dim)', flex: 'none', width: 46 }}>{e.level}</span>
            <span style={{ whiteSpace: 'pre-wrap' }}>{e.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
