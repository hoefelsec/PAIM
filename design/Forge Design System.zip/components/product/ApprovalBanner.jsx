import React from 'react';
import { Icon } from '../core/Icon.jsx';

/* Human checkpoint. Appears inline above the work it gates — never as a modal. */
export function ApprovalBanner({ title, description, actions, tone = 'accent', style, ...rest }) {
  const bg = tone === 'accent' ? 'var(--accent-soft)' : 'var(--warning-bg)';
  const bd = tone === 'accent' ? 'var(--accent-soft-border)' : 'transparent';
  const fg = tone === 'accent' ? 'var(--text-accent)' : 'var(--warning-fg)';
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 11, padding: '11px 12px',
      background: bg, border: '1px solid ' + bd, borderRadius: 'var(--radius-lg)', ...style,
    }} {...rest}>
      <Icon name="shield-check" size={16} style={{ color: fg, flex: 'none' }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: 'var(--type-ui)', color: 'var(--text-primary)' }}>{title}</div>
        {description ? <div style={{ font: 'var(--type-caption)', color: 'var(--text-secondary)', marginTop: 2 }}>{description}</div> : null}
      </div>
      {actions ? <div style={{ display: 'flex', gap: 6, flex: 'none' }}>{actions}</div> : null}
    </div>
  );
}
