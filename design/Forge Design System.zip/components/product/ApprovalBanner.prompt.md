Sits inline above the artifact awaiting sign-off — never a modal, because approval should not block the rest of the workspace.

```jsx
<ApprovalBanner title="Atlas needs approval to deploy"
  description="Milestone 2 of 4 · staging verified"
  actions={<><Button size="sm">Request changes</Button><Button size="sm" variant="primary">Approve</Button></>} />
```
