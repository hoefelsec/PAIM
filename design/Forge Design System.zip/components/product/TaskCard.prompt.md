Kanban card. Agent-run tasks show a progress track and the ember agent pill instead of a human avatar.

```jsx
<TaskCard id="FRG-214" title="Migrate billing webhooks" status="running" priority="high"
  agent="Atlas" progress={62} labels={[{name:'infra',color:'var(--blue-500)'}]} comments={3} />
```
