import React from 'react';
import { Icon } from '../core/Icon.jsx';

export const STATUSES = {
  'open-questions': { label: 'Open questions', icon: 'circle-help', color: 'var(--status-open-questions)' },
  design: { label: 'Design', icon: 'shapes', color: 'var(--status-design)' },
  ready: { label: 'Ready', icon: 'circle', color: 'var(--status-ready)' },
  running: { label: 'Running', icon: 'loader-circle', color: 'var(--status-running)' },
  testing: { label: 'Testing', icon: 'flask-conical', color: 'var(--status-testing)' },
  reviewing: { label: 'Reviewing', icon: 'circle-user-round', color: 'var(--status-reviewing)' },
  paused: { label: 'Paused', icon: 'circle-pause', color: 'var(--status-paused)' },
  failed: { label: 'Failed', icon: 'circle-x', color: 'var(--status-failed)' },
  canceled: { label: 'Canceled', icon: 'circle-slash', color: 'var(--status-canceled)' },
  done: { label: 'Done', icon: 'circle-check', color: 'var(--status-done)' },
};

/* The single source of truth for task lifecycle state across every Forge view. */
export function StatusPill({ status = 'ready', showLabel = true, size = 'md', style, ...rest }) {
  const s = STATUSES[status] || STATUSES.ready;
  const px = size === 'sm' ? 12 : 14;
  const spin = status === 'running';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6, color: 'var(--text-secondary)',
      font: 'var(--type-ui)', fontSize: size === 'sm' ? 'var(--text-xs)' : 'var(--text-sm)', ...style,
    }} {...rest}>
      <Icon name={s.icon} size={px} style={{ color: s.color, animation: spin ? 'forge-spin 1.6s linear infinite' : undefined }} />
      {showLabel ? s.label : null}
    </span>
  );
}
