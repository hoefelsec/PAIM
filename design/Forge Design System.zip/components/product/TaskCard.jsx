import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { Avatar } from '../core/Avatar.jsx';
import { Tag } from '../core/Tag.jsx';
import { StatusPill } from './StatusPill.jsx';
import { AgentRunIndicator } from './AgentRunIndicator.jsx';
import { ProgressBar } from '../feedback/ProgressBar.jsx';

const PRIORITY = { urgent: ['signal-high', 'var(--danger-fg)'], high: ['signal-high', 'var(--warning-fg)'], medium: ['signal-medium', 'var(--text-tertiary)'], low: ['signal-low', 'var(--text-disabled)'] };

/* The Kanban/list unit of work. Agent-run tasks show live progress instead of a static assignee. */
export function TaskCard({ id, title, status = 'ready', priority = 'medium', labels = [], assignee, agent, progress, due, comments, attachments, selected = false, onClick, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const [pIcon, pColor] = PRIORITY[priority] || PRIORITY.medium;
  return (
    <div onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', flexDirection: 'column', gap: 8, padding: 10,
        background: 'var(--surface-card)', borderRadius: 'var(--radius-lg)',
        border: '1px solid ' + (selected ? 'var(--border-accent)' : 'var(--border-default)'),
        boxShadow: hover ? 'var(--shadow-md)' : 'var(--shadow-xs)', cursor: 'pointer',
        transition: 'box-shadow var(--duration-normal) var(--ease-standard), border-color var(--duration-fast) var(--ease-standard)', ...style,
      }} {...rest}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-disabled)' }}>{id}</span>
        <Icon name={pIcon} size={13} style={{ color: pColor }} />
      </div>
      <div style={{ font: 'var(--type-ui)', fontWeight: 'var(--weight-medium)', color: 'var(--text-primary)', lineHeight: 1.35 }}>{title}</div>
      {agent && progress != null ? <ProgressBar value={progress} size="sm" /> : null}
      {labels.length ? (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
          {labels.map(l => <Tag key={l.name} color={l.color}>{l.name}</Tag>)}
        </div>
      ) : null}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 1 }}>
        {agent ? <AgentRunIndicator agent={agent} compact state={status === 'running' ? 'running' : 'idle'} />
          : <StatusPill status={status} size="sm" showLabel={false} />}
        <span style={{ flex: 1 }} />
        {comments ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, font: 'var(--type-caption)', color: 'var(--text-tertiary)' }}><Icon name="message-square" size={12} />{comments}</span> : null}
        {attachments ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, font: 'var(--type-caption)', color: 'var(--text-tertiary)' }}><Icon name="paperclip" size={12} />{attachments}</span> : null}
        {due ? <span style={{ font: 'var(--type-caption)', color: 'var(--text-tertiary)' }}>{due}</span> : null}
        {assignee ? <Avatar name={assignee} size="xs" /> : null}
      </div>
    </div>
  );
}
