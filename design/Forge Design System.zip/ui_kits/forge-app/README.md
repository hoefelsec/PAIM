# Forge app — UI kit

High-fidelity recreation of the Forge workspace: where people delegate tasks to AI agents and supervise execution. **Dark by default** — the app is a single-theme instrument.

Open `index.html`. It is a click-through, not production code — data is static (`data.js`), but the rail, panel, dialog, dock and toasts all work.

## Shell

| File | Piece | Notes |
| --- | --- | --- |
| `AppShell.jsx` | Workspace switcher, facet rail, toolbar, stats band, activity dock | A project is a **workspace**, not a sidebar item — picking one re-scopes the whole UI, which frees the rail for faceted filtering (status from the pipeline, the rest from the workspace schema, each with live counts). |
| `BoardScreen.jsx` | The board | The only view. A switcher with one option is chrome, so the toolbar names the saved filter set ("Open work") rather than offering List / Calendar / Timeline. |
| `TaskView.jsx` | Task detail | Opens **full-pane** over the board: title, a two-column property grid (status, agent, priority, model, size, reviewer, labels, due, branch, updated), then the pipeline as a tab bar. |

## Layout rules worth keeping

- **Stats band** under the toolbar carries what the workspace *is* on the left (version, task counts) and what it is *costing* on the right — token-budget meters that turn amber past 100%.
- **Activity dock** spans the full window width, *under* the sidebar, because it is global: every run in every workspace, active above queued. Collapsible from its header.
- **The task view is the pipeline.** Tabs are Description · Questions · Design · Execution · Test · Review. A tab is **disabled until the task reaches its stage**, and the tab matching the current status is **highlighted in ember and selected on open** — a running task lands on Execution, a task in open questions lands on Questions. Escape returns to the board.
- **Density**: 240px rail, 12/18px toolbar padding, 6px dock rows, mono for every machine-produced value.

## Interactions worth clicking

- Click a board card → the full task view opens on the stage that matches its status; **Esc** goes back.
- Open cards in different columns to see which tabs unlock: FRG-226 (open questions) has Execution/Test/Review disabled; FRG-208 (reviewing) has everything.
- **Approve** in the Execution or Review tab resolves the checkpoint and fires a toast.
- **New task** (or the **C** key) opens the creation dialog; *Create & run* queues an agent.
- Click a filter value (e.g. **Status: 2 selected**) to open its checkbox menu; picking one shows that value inline, picking more collapses to a count. Only one menu is open at a time; Esc or an outside click closes it.
- The workspace tile at top-left opens the workspace menu.
- The dock header collapses and expands the global run list.

## Composition rule

Everything comes from the published components (`window.ForgeDesignSystem_8868ce`). The shell only lays out and wires state; the rail, meters and dock rows are kit-level compositions, not new primitives.
