const { Button, Icon, Badge, Card, Switch } = window.ForgeDesignSystem_8868ce;

const PLANS = [
  { name: 'Free', price: '$0', unit: 'forever', desc: 'For solo work and evaluation.', cta: 'Start free', variant: 'secondary', features: ['3 agents', '200 runs / month', 'List and board views', 'Community support'] },
  { name: 'Team', price: '$24', unit: 'per seat / month', desc: 'For teams running agents daily.', cta: 'Start 14-day trial', variant: 'primary', featured: true, features: ['Unlimited agents', '5,000 runs / month', 'All four views', 'Approval checkpoints', 'Execution log retention 90d', 'Priority support'] },
  { name: 'Enterprise', price: 'Custom', unit: 'annual', desc: 'For regulated and large orgs.', cta: 'Talk to sales', variant: 'secondary', features: ['Bring your own models', 'SSO + SCIM', 'Audit export', 'Unlimited retention', 'Dedicated support'] },
];

function PricingPage() {
  const [annual, setAnnual] = React.useState(true);
  return (
    <Section style={{ paddingTop: 64, paddingBottom: 80 }}>
      <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, marginBottom: 34 }}>
        <h1 style={{ font: 'var(--type-h1)', fontSize: 44, letterSpacing: 'var(--tracking-tighter)', color: 'var(--text-primary)', margin: 0 }}>Priced per person, not per agent</h1>
        <p style={{ font: 'var(--type-body-lg)', color: 'var(--text-secondary)', margin: 0, maxWidth: 460 }}>Run as much work as you like. We charge for the humans supervising it.</p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 4 }}>
          <Switch checked={annual} onChange={setAnnual} label="Annual billing" />
          <Badge tone="success" size="sm">2 months free</Badge>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14, alignItems: 'start' }}>
        {PLANS.map(p => (
          <Card key={p.name} padding="lg" selected={p.featured} elevation={p.featured ? 'lg' : 'sm'}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ font: 'var(--type-h3)', color: 'var(--text-primary)' }}>{p.name}</span>
              {p.featured ? <Badge tone="accent" size="sm">Most teams</Badge> : null}
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 14 }}>
              <span style={{ font: 'var(--type-display)', fontSize: 40, letterSpacing: 'var(--tracking-tighter)', color: 'var(--text-primary)' }}>{p.price}</span>
              <span style={{ font: 'var(--type-caption)', color: 'var(--text-tertiary)' }}>{p.unit}</span>
            </div>
            <p style={{ font: 'var(--type-body)', color: 'var(--text-secondary)', margin: '8px 0 16px' }}>{p.desc}</p>
            <Button variant={p.variant} fullWidth>{p.cta}</Button>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 18, paddingTop: 16, borderTop: '1px solid var(--border-subtle)' }}>
              {p.features.map(ft => (
                <span key={ft} style={{ display: 'flex', alignItems: 'center', gap: 8, font: 'var(--type-body)', color: 'var(--text-body)' }}>
                  <Icon name="check" size={14} style={{ color: 'var(--status-done)' }} />{ft}
                </span>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </Section>
  );
}

Object.assign(window, { PricingPage });
