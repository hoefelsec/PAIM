# Forge web — UI kit

The public marketing surface. Open `index.html`; the top nav switches between the three pages client-side.

| File | Page |
| --- | --- |
| `SiteChrome.jsx` | Sticky translucent nav + footer, shared by every page. |
| `HomePage.jsx` | Hero with a live product frame, logo row, six-up feature grid, dark lifecycle band, closing CTA. |
| `PricingPage.jsx` | Three plans, annual toggle, feature checklists. |
| `ChangelogPage.jsx` | Version-stamped release entries in a two-column layout. |

Marketing shares the app's tokens exactly — same neutrals, same ember, same radii. The only marketing-specific moves are the larger display sizes (38–62px), the wider `--gutter-section` rhythm, and the one dark full-bleed band in the lifecycle section.

The hero product frame is composed from the real `TaskCard`, `ExecutionLog`, `AgentRunIndicator` and `ApprovalBanner` components rather than a screenshot, so it stays in sync with the system.
