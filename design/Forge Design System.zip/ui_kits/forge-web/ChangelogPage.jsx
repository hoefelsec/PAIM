const { Badge, Icon, Card, Avatar } = window.ForgeDesignSystem_8868ce;

const ENTRIES = [
  { v: '2.14.0', date: 'Aug 4, 2026', tag: ['accent', 'Agents'], title: 'Step-through runs', body: 'Pause an agent at every milestone instead of only at approval gates. Useful when you are still learning how a new agent behaves on your codebase.', bullets: ['New run mode in the task dialog', 'Resume from any completed step', 'Step plans render in the task rail'] },
  { v: '2.13.2', date: 'Jul 28, 2026', tag: ['success', 'Fix'], title: 'Execution log retention', body: 'Logs no longer truncate at 5,000 lines on Team plans. Retention now follows the plan, not the buffer.', bullets: [] },
  { v: '2.13.0', date: 'Jul 21, 2026', tag: ['info', 'Views'], title: 'Timeline view', body: 'Agent runs now render as durations on a shared timeline, with approval gates marked inline.', bullets: ['Drag to reschedule', 'Critical-path highlighting'] },
];

function ChangelogPage() {
  return (
    <Section style={{ paddingTop: 64, paddingBottom: 80 }}>
      <h1 style={{ font: 'var(--type-h1)', fontSize: 44, letterSpacing: 'var(--tracking-tighter)', color: 'var(--text-primary)', margin: '0 0 6px' }}>Changelog</h1>
      <p style={{ font: 'var(--type-body-lg)', color: 'var(--text-secondary)', margin: '0 0 36px' }}>What shipped, in plain language.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
        {ENTRIES.map(e => (
          <div key={e.v} style={{ display: 'grid', gridTemplateColumns: '160px 1fr', gap: 24 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, paddingTop: 2 }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-sm)', color: 'var(--text-primary)' }}>{e.v}</span>
              <span style={{ font: 'var(--type-caption)', color: 'var(--text-tertiary)' }}>{e.date}</span>
              <Badge tone={e.tag[0]} size="sm" style={{ alignSelf: 'flex-start' }}>{e.tag[1]}</Badge>
            </div>
            <Card padding="md">
              <h2 style={{ font: 'var(--type-h2)', fontSize: 21, letterSpacing: 'var(--tracking-tight)', color: 'var(--text-primary)', margin: '0 0 8px' }}>{e.title}</h2>
              <p style={{ font: 'var(--type-body-lg)', color: 'var(--text-body)', margin: 0, maxWidth: 'var(--prose-max)' }}>{e.body}</p>
              {e.bullets.length ? (
                <ul style={{ margin: '12px 0 0', padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {e.bullets.map(b => (
                    <li key={b} style={{ display: 'flex', gap: 8, alignItems: 'center', font: 'var(--type-body)', color: 'var(--text-secondary)' }}>
                      <Icon name="corner-down-right" size={13} style={{ color: 'var(--text-disabled)' }} />{b}
                    </li>
                  ))}
                </ul>
              ) : null}
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 16, paddingTop: 12, borderTop: '1px solid var(--border-subtle)' }}>
                <Avatar name="Dev Okafor" size="xs" />
                <span style={{ font: 'var(--type-caption)', color: 'var(--text-tertiary)' }}>Dev Okafor · Engineering</span>
              </div>
            </Card>
          </div>
        ))}
      </div>
    </Section>
  );
}

Object.assign(window, { ChangelogPage });
