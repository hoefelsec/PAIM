const { Button, Icon, Badge, Card, TaskCard, AgentRunIndicator, ExecutionLog, StatusPill, ApprovalBanner, Kbd } = window.ForgeDesignSystem_8868ce;

function Section({ children, style }) {
  return <section style={{ padding: '0 28px', ...style }}><div style={{ maxWidth: 'var(--content-max)', margin: '0 auto' }}>{children}</div></section>;
}

function Hero() {
  return (
    <Section style={{ paddingTop: 84, paddingBottom: 56 }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', gap: 18 }}>
        <Badge tone="accent" icon="sparkles">Agent runs are now generally available</Badge>
        <h1 style={{ font: 'var(--type-display)', fontSize: 62, letterSpacing: 'var(--tracking-tighter)', color: 'var(--text-primary)', margin: 0, maxWidth: 780 }}>
          Tasks that execute themselves
        </h1>
        <p style={{ font: 'var(--type-body-lg)', fontSize: 18, color: 'var(--text-secondary)', margin: 0, maxWidth: 560 }}>
          Forge is a project manager where work is delegated to AI agents, not just assigned to people. Define the objective, watch every action, approve what matters.
        </p>
        <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
          <Button variant="primary" size="lg" iconEnd="arrow-right">Start free</Button>
          <Button size="lg" icon="play">Watch a run</Button>
        </div>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center', font: 'var(--type-caption)', color: 'var(--text-tertiary)' }}>
          Free for 3 agents · no card required
        </div>
      </div>
      <div style={{
        marginTop: 44, borderRadius: 'var(--radius-2xl)', border: '1px solid var(--border-default)',
        background: 'var(--surface-card)', boxShadow: 'var(--shadow-xl)', overflow: 'hidden',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, height: 38, padding: '0 12px', borderBottom: '1px solid var(--border-subtle)', background: 'var(--surface-sunken)' }}>
          <span style={{ display: 'flex', gap: 5 }}>{['var(--gray-300)', 'var(--gray-300)', 'var(--gray-300)'].map((c, i) => <span key={i} style={{ width: 9, height: 9, borderRadius: 999, background: c }} />)}</span>
          <span style={{ font: 'var(--type-caption)', color: 'var(--text-tertiary)', marginLeft: 8 }}>Billing v2 · FRG-214</span>
          <span style={{ flex: 1 }} />
          <AgentRunIndicator agent="Atlas" step="running tests" elapsed="2m 14s" compact />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.25fr', gap: 16, padding: 16, background: 'var(--surface-page)' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <TaskCard id="FRG-214" title="Migrate billing webhooks to the v2 API" status="running" priority="high" agent="Atlas" progress={62} labels={[{ name: 'infra', color: 'var(--blue-500)' }]} comments={3} />
            <TaskCard id="FRG-208" title="Draft the migration runbook" status="reviewing" priority="medium" agent="Scribe" progress={100} labels={[{ name: 'docs', color: 'var(--gray-400)' }]} comments={8} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <ExecutionLog live height={150} entries={[
              { time: '14:02:11', level: 'tool', message: 'read_file("billing/webhooks.ts")' },
              { time: '14:02:14', level: 'tool', message: 'search_repo("stripe.constructEvent")' },
              { time: '14:02:31', level: 'ok', message: '12 handlers ported · 31 tests generated' },
              { time: '14:02:44', level: 'warn', message: 'retry: rate limit on staging deploy (1/3)' },
              { time: '14:02:51', level: 'ok', message: '31/31 tests passing' },
            ]} />
            <ApprovalBanner title="Approve deploy to staging" description="Milestone 2 of 4 · 12 files changed" actions={<Button size="sm" variant="primary" icon="check">Approve</Button>} />
          </div>
        </div>
      </div>
    </Section>
  );
}

function LogoRow() {
  return (
    <Section style={{ paddingBottom: 56 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 40, flexWrap: 'wrap', opacity: .5 }}>
        {['Northwind', 'Cobalt', 'Harbor Labs', 'Vantage', 'Meridian', 'Rift'].map(n => (
          <span key={n} style={{ fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 17, letterSpacing: '-.02em', color: 'var(--text-secondary)' }}>{n}</span>
        ))}
      </div>
    </Section>
  );
}

function Features() {
  const items = [
    ['Delegate, do not dispatch', 'sparkles', 'Assign a task to an agent the same way you assign it to a teammate. It picks up the objective, the files and the constraints.'],
    ['Every action, on the record', 'terminal', 'A timestamped execution log for every run. Tool calls, retries, failures — nothing is summarised away.'],
    ['Approvals where they matter', 'shield-check', 'Gate a milestone and the agent pauses. Approve, request changes, or take the work back — inline, never in a modal.'],
    ['Status that updates itself', 'refresh-cw', 'Progress, state and due-date risk move as the agent works. Nobody drags a card to keep a board honest.'],
    ['Four views, one dataset', 'columns-3', 'List, board, calendar and timeline over the same tasks. Switch with a keystroke.'],
    ['Keyboard first', 'command', 'Every action has a shortcut. ⌘K reaches any project, task or agent in the workspace.'],
  ];
  return (
    <Section style={{ paddingBottom: 72 }}>
      <h2 style={{ font: 'var(--type-h1)', fontSize: 34, letterSpacing: 'var(--tracking-tight)', color: 'var(--text-primary)', margin: '0 0 6px' }}>An execution platform, not a task list</h2>
      <p style={{ font: 'var(--type-body-lg)', color: 'var(--text-secondary)', margin: '0 0 28px', maxWidth: 520 }}>Forge tracks work the way a build system tracks jobs — with state, logs and artifacts.</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14 }}>
        {items.map(([t, ic, d]) => (
          <Card key={t} padding="md">
            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 30, height: 30, borderRadius: 'var(--radius-md)', background: 'var(--accent-soft)', color: 'var(--text-accent)', border: '1px solid var(--accent-soft-border)' }}>
              <Icon name={ic} size={15} />
            </span>
            <h3 style={{ font: 'var(--type-h3)', color: 'var(--text-primary)', margin: '12px 0 4px' }}>{t}</h3>
            <p style={{ font: 'var(--type-body)', color: 'var(--text-secondary)', margin: 0 }}>{d}</p>
          </Card>
        ))}
      </div>
    </Section>
  );
}

function Lifecycle() {
  const steps = [['ready', 'Define', 'Objective, instructions, files, deadline.'], ['running', 'Execute', 'The agent works, logging every tool call.'], ['testing', 'Verify', 'Tests run; failures come back with the log.'], ['reviewing', 'Review', 'You approve, comment, or take over.'], ['done', 'Ship', 'Artifacts attached, status closed automatically.']];
  return (
    <Section style={{ paddingBottom: 72 }}>
      <div style={{ background: 'var(--gray-950)', borderRadius: 'var(--radius-2xl)', padding: '40px 36px' }}>
        <h2 style={{ font: 'var(--type-h1)', fontSize: 32, letterSpacing: 'var(--tracking-tight)', color: '#fff', margin: '0 0 28px', maxWidth: 460 }}>The whole lifecycle, visible in one place</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 18 }}>
          {steps.map(([s, t, d], i) => (
            <div key={t} style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingTop: 16, borderTop: '1px solid rgba(255,255,255,.14)' }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--ember-400)' }}>0{i + 1}</span>
              <span style={{ font: 'var(--type-h3)', color: '#fff' }}>{t}</span>
              <span style={{ font: 'var(--type-body)', color: 'rgba(255,255,255,.62)' }}>{d}</span>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}

function CTA() {
  return (
    <Section style={{ paddingBottom: 84 }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, textAlign: 'center', padding: '48px 24px', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-2xl)', background: 'var(--surface-card)' }}>
        <h2 style={{ font: 'var(--type-h1)', fontSize: 36, letterSpacing: 'var(--tracking-tight)', color: 'var(--text-primary)', margin: 0 }}>Put your backlog to work</h2>
        <p style={{ font: 'var(--type-body-lg)', color: 'var(--text-secondary)', margin: 0, maxWidth: 420 }}>Three agents free, forever. Connect a repo and run your first task in under five minutes.</p>
        <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
          <Button variant="primary" size="lg" iconEnd="arrow-right">Start free</Button>
          <Button size="lg">Talk to sales</Button>
        </div>
      </div>
    </Section>
  );
}

function HomePage() {
  return <><Hero /><LogoRow /><Features /><Lifecycle /><CTA /></>;
}

Object.assign(window, { HomePage, Section });
