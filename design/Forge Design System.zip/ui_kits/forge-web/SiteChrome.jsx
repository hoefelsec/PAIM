const { Button, Icon, Badge } = window.ForgeDesignSystem_8868ce;

function SiteNav({ route, setRoute }) {
  const link = (id, label) => (
    <button key={id} onClick={() => setRoute(id)} style={{
      border: 0, background: 'none', cursor: 'pointer', padding: '0 2px',
      font: 'var(--type-ui)', color: route === id ? 'var(--text-primary)' : 'var(--text-secondary)',
    }}>{label}</button>
  );
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 30, display: 'flex', alignItems: 'center', gap: 22,
      height: 58, padding: '0 28px', background: 'rgba(251,251,250,.82)',
      backdropFilter: 'var(--blur-overlay)', borderBottom: '1px solid var(--border-subtle)',
    }}>
      <button onClick={() => setRoute('home')} style={{ display: 'flex', alignItems: 'center', gap: 8, border: 0, background: 'none', cursor: 'pointer', padding: 0, fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 17, letterSpacing: '-.03em', color: 'var(--text-primary)' }}>
        <img src="../../assets/logo.svg" alt="" width="19" height="19" />Forge</button>
      <nav style={{ display: 'flex', gap: 18 }}>
        {link('home', 'Product')}{link('pricing', 'Pricing')}{link('changelog', 'Changelog')}
        <a href="#docs" style={{ font: 'var(--type-ui)', color: 'var(--text-secondary)' }}>Docs</a>
      </nav>
      <span style={{ flex: 1 }} />
      <a href="#signin" style={{ font: 'var(--type-ui)', color: 'var(--text-secondary)' }}>Sign in</a>
      <Button variant="primary" size="sm" iconEnd="arrow-right">Start free</Button>
    </header>
  );
}

function SiteFooter() {
  const col = (title, items) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <span style={{ font: 'var(--type-overline)', letterSpacing: 'var(--tracking-caps)', textTransform: 'uppercase', color: 'var(--text-disabled)' }}>{title}</span>
      {items.map(i => <a key={i} href="#" style={{ font: 'var(--type-ui)', fontWeight: 400, color: 'var(--text-secondary)' }}>{i}</a>)}
    </div>
  );
  return (
    <footer style={{ borderTop: '1px solid var(--border-subtle)', padding: '44px 28px 32px', background: 'var(--surface-card)' }}>
      <div style={{ maxWidth: 'var(--content-max)', margin: '0 auto', display: 'grid', gridTemplateColumns: '1.4fr repeat(3, 1fr)', gap: 32 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 17, letterSpacing: '-.03em', color: 'var(--text-primary)' }}>
            <img src="../../assets/logo.svg" alt="" width="19" height="19" />Forge</div>
          <p style={{ font: 'var(--type-caption)', color: 'var(--text-tertiary)', maxWidth: 260, marginTop: 6 }}>Define the goal. Delegate the work. Watch it run.</p>
        </div>
        {col('Product', ['Agents', 'Views', 'Approvals', 'Integrations'])}
        {col('Company', ['About', 'Careers', 'Blog', 'Security'])}
        {col('Resources', ['Docs', 'Changelog', 'Status', 'Contact'])}
      </div>
      <div style={{ maxWidth: 'var(--content-max)', margin: '32px auto 0', display: 'flex', gap: 14, font: 'var(--type-caption)', color: 'var(--text-disabled)' }}>
        <span>© 2026 Forge Labs</span><span>·</span><span>Privacy</span><span>·</span><span>Terms</span>
      </div>
    </footer>
  );
}

Object.assign(window, { SiteNav, SiteFooter });
